package dashboard;

import do_an.DBConnection;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import org.jfree.chart.*;
import org.jfree.chart.plot.*;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;

public class DashboardPanel extends JPanel {
    private Connection conn;
    private JPanel chartContainer;
    private JTable dataTable;
    private DefaultTableModel tableModel;

    private String[] buttonNames = {
        "Đơn hàng", "Sản phẩm", "Khách hàng", "Người bán", "Doanh thu",
        "Top sản phẩm", "Top khách hàng", "Đơn hàng theo ngày", "Phân loại đơn hàng", "Đánh giá seller"
    };
    private JButton[] buttons = new JButton[buttonNames.length];

    public DashboardPanel() {
        setLayout(new BorderLayout());
        conn = DBConnection.getConnection();

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        buttonPanel.setBackground(new Color(30, 30, 30));

        for (int i = 0; i < buttonNames.length; i++) {
            JButton btn = new JButton(buttonNames[i]);
            btn.setFocusPainted(false);
            btn.setForeground(Color.white);
            btn.setBackground(new Color(70, 130, 180));
            btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            int index = i;
            btn.addActionListener(e -> switchDashboard(index));
            btn.addMouseListener(new MouseAdapter() {
                public void mouseEntered(MouseEvent e) {
                    btn.setBackground(new Color(100, 149, 237));
                }
                public void mouseExited(MouseEvent e) {
                    btn.setBackground(new Color(70, 130, 180));
                }
            });
            buttons[i] = btn;
            buttonPanel.add(btn);
        }

        add(buttonPanel, BorderLayout.NORTH);

        chartContainer = new JPanel(new BorderLayout());
        chartContainer.setPreferredSize(new Dimension(600, 400));
        add(chartContainer, BorderLayout.CENTER);

        tableModel = new DefaultTableModel();
        dataTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(dataTable);
        scrollPane.setPreferredSize(new Dimension(400, 0));
        add(scrollPane, BorderLayout.EAST);

        switchDashboard(0);
    }

    private void switchDashboard(int index) {
        chartContainer.removeAll();
        tableModel.setRowCount(0);
        tableModel.setColumnCount(0);

        try {
            switch (index) {
                case 0:
                    chartContainer.add(createPieChartOrderStatus(), BorderLayout.CENTER);
                    loadTable("SELECT status, COUNT(*) AS SoLuong FROM orders GROUP BY status");
                    break;
                case 1:
                    chartContainer.add(createBarChartProductCategory(), BorderLayout.CENTER);
                    loadTable("SELECT category, COUNT(*) AS SoLuong FROM products GROUP BY category");
                    break;
                case 2:
                    chartContainer.add(createBarChartCustomersByRegion(), BorderLayout.CENTER);
                    loadTable("SELECT region, COUNT(*) AS SoLuong FROM customers GROUP BY region");
                    break;
                case 3:
                    chartContainer.add(createBarChartSellersByRating(), BorderLayout.CENTER);
                    loadTable("SELECT name, AVG(rating) AS DanhGia FROM sellers GROUP BY name ORDER BY DanhGia DESC LIMIT 20");
                    break;
                case 4:
                    chartContainer.add(createLineChartRevenueByMonth(), BorderLayout.CENTER);
                    loadTable("SELECT DATE_FORMAT(order_date, '%Y-%m') AS Thang, SUM(total_amount) AS DoanhThu FROM orders GROUP BY Thang ORDER BY Thang");
                    break;
                case 5:
                    chartContainer.add(createBarChartTopProducts(), BorderLayout.CENTER);
                    loadTable("SELECT name, SUM(quantity) AS SoLuong FROM order_items JOIN products ON order_items.product_id = products.product_id GROUP BY name ORDER BY SoLuong DESC LIMIT 10");
                    break;
                case 6:
                    chartContainer.add(createBarChartTopCustomers(), BorderLayout.CENTER);
                    loadTable("SELECT customers.name, SUM(total_amount) AS TongChi FROM orders JOIN customers ON orders.customer_id = customers.customer_id GROUP BY customers.name ORDER BY TongChi DESC LIMIT 10");
                    break;
                case 7:
                    chartContainer.add(createLineChartOrdersByDate(), BorderLayout.CENTER);
                    loadTable("SELECT order_date, COUNT(*) AS SoLuong FROM orders GROUP BY order_date ORDER BY order_date");
                    break;
                case 8:
                    chartContainer.add(createPieChartOrderCategory(), BorderLayout.CENTER);
                    loadTable("SELECT category, COUNT(*) AS SoLuong FROM orders GROUP BY category");
                    break;
                case 9:
                    chartContainer.add(createBarChartSellerRatings(), BorderLayout.CENTER);
                    loadTable("SELECT seller_id, AVG(rating) AS DanhGia FROM orders GROUP BY seller_id ORDER BY DanhGia DESC LIMIT 10");
                    break;
                default:
                    chartContainer.add(new JLabel("Không có dữ liệu"));
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage());
        }

        chartContainer.revalidate();
        chartContainer.repaint();
    }

    private void loadTable(String query) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {
            ResultSetMetaData meta = rs.getMetaData();
            int columnCount = meta.getColumnCount();
            for (int i = 1; i <= columnCount; i++) {
                tableModel.addColumn(meta.getColumnName(i));
            }
            while (rs.next()) {
                Object[] row = new Object[columnCount];
                for (int i = 1; i <= columnCount; i++) {
                    row[i - 1] = rs.getObject(i);
                }
                tableModel.addRow(row);
            }
        }
    }

    private ChartPanel createPieChartOrderStatus() throws SQLException {
        String sql = "SELECT status, COUNT(*) AS total_orders FROM orders GROUP BY status";
        DefaultPieDataset dataset = new DefaultPieDataset();
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                dataset.setValue(rs.getString("status"), rs.getInt("total_orders"));
            }
        }
        JFreeChart chart = ChartFactory.createPieChart("Tỷ lệ đơn hàng theo trạng thái", dataset, true, true, false);
        return new ChartPanel(chart);
    }

    private ChartPanel createPieChartOrderCategory() throws SQLException {
        String sql = "SELECT category, COUNT(*) AS total_orders FROM orders GROUP BY category";
        DefaultPieDataset dataset = new DefaultPieDataset();
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                dataset.setValue(rs.getString("category"), rs.getInt("total_orders"));
            }
        }
        JFreeChart chart = ChartFactory.createPieChart("Tỷ lệ đơn hàng theo loại", dataset, true, true, false);
        return new ChartPanel(chart);
    }

    private ChartPanel createBarChartProductCategory() throws SQLException {
        String sql = "SELECT category, COUNT(*) AS total_products FROM products GROUP BY category";
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                dataset.addValue(rs.getInt("total_products"), "Sản phẩm", rs.getString("category"));
            }
        }
        JFreeChart chart = ChartFactory.createBarChart("Sản phẩm theo danh mục", "Danh mục", "Số lượng", dataset);
        return new ChartPanel(chart);
    }

    private ChartPanel createBarChartCustomersByRegion() throws SQLException {
        String sql = "SELECT region, COUNT(*) AS total_customers FROM customers GROUP BY region";
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                dataset.addValue(rs.getInt("total_customers"), "Khách hàng", rs.getString("region"));
            }
        }
        JFreeChart chart = ChartFactory.createBarChart("Khách hàng theo vùng", "Vùng", "Số lượng", dataset);
        return new ChartPanel(chart);
    }

    private ChartPanel createBarChartSellersByRating() throws SQLException {
        String sql = "SELECT name, AVG(rating) AS avg_rating FROM sellers GROUP BY name ORDER BY avg_rating DESC LIMIT 20";
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                dataset.addValue(rs.getDouble("avg_rating"), "Đánh giá", rs.getString("name"));
            }
        }
        JFreeChart chart = ChartFactory.createBarChart("Đánh giá người bán", "Người bán", "Đánh giá", dataset);
        return new ChartPanel(chart);
    }

    private ChartPanel createLineChartRevenueByMonth() throws SQLException {
        String sql = "SELECT DATE_FORMAT(order_date, '%Y-%m') AS month, SUM(total_amount) AS revenue FROM orders GROUP BY month ORDER BY month";
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                dataset.addValue(rs.getDouble("revenue"), "Doanh thu", rs.getString("month"));
            }
        }
        JFreeChart chart = ChartFactory.createLineChart("Doanh thu theo tháng", "Tháng", "Doanh thu", dataset);
        return new ChartPanel(chart);
    }

    private ChartPanel createLineChartOrdersByDate() throws SQLException {
        String sql = "SELECT order_date, COUNT(*) AS total_orders FROM orders GROUP BY order_date ORDER BY order_date";
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                dataset.addValue(rs.getInt("total_orders"), "Đơn hàng", rs.getString("order_date"));
            }
        }
        JFreeChart chart = ChartFactory.createLineChart("Đơn hàng theo ngày", "Ngày", "Số lượng", dataset);
        return new ChartPanel(chart);
    }

    private ChartPanel createBarChartTopProducts() throws SQLException {
        String sql = "SELECT products.name, SUM(quantity) AS total_sold FROM order_items JOIN products ON order_items.product_id = products.product_id GROUP BY products.name ORDER BY total_sold DESC LIMIT 10";
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                dataset.addValue(rs.getInt("total_sold"), "Sản phẩm", rs.getString("name"));
            }
        }
        JFreeChart chart = ChartFactory.createBarChart("Top 10 sản phẩm bán chạy", "Sản phẩm", "Số lượng", dataset);
        return new ChartPanel(chart);
    }

    private ChartPanel createBarChartTopCustomers() throws SQLException {
        String sql = "SELECT customers.name, SUM(total_amount) AS total_spent FROM orders JOIN customers ON orders.customer_id = customers.customer_id GROUP BY customers.name ORDER BY total_spent DESC LIMIT 10";
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                dataset.addValue(rs.getDouble("total_spent"), "Khách hàng", rs.getString("name"));
            }
        }
        JFreeChart chart = ChartFactory.createBarChart("Top 10 khách hàng chi tiêu nhiều nhất", "Khách hàng", "Chi tiêu", dataset);
        return new ChartPanel(chart);
    }

    private ChartPanel createBarChartSellerRatings() throws SQLException {
        String sql = "SELECT seller_id, AVG(rating) AS avg_rating FROM orders GROUP BY seller_id ORDER BY avg_rating DESC LIMIT 10";
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                dataset.addValue(rs.getDouble("avg_rating"), "Seller", rs.getString("seller_id"));
            }
        }
        JFreeChart chart = ChartFactory.createBarChart("Top 10 người bán được đánh giá cao", "Seller ID", "Đánh giá", dataset);
        return new ChartPanel(chart);
    }
}