package do_an.ui;

import do_an.ui.FavoriteManager;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class ShoppingCartApp extends JFrame {
    private JTable cartTable;
    private DefaultTableModel tableModel;
    private JButton btnRemove, btnCheckout, btnBack, btnFavorites;
    private Color[] gradientColors = { Color.CYAN, Color.MAGENTA, Color.ORANGE, Color.PINK };
    private int colorIndex = 0;
    private JPanel contentPanel;

    public ShoppingCartApp() {
        setTitle("🛒 Giỏ hàng - Dark Mode");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(850, 550);
        setLocationRelativeTo(null);
        setUndecorated(true);

        contentPanel = new AnimatedGridPanel();
        contentPanel.setLayout(new BorderLayout());
        contentPanel.setBorder(BorderFactory.createLineBorder(gradientColors[0], 3));

        JLabel title = new JLabel("🛒 GIỎ HÀNG CỦA BẠN", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 28));
        title.setForeground(Color.WHITE);
        title.setBorder(new EmptyBorder(20, 0, 20, 0));
        contentPanel.add(title, BorderLayout.NORTH);

        String[] columnNames = {"Sản phẩm", "Số lượng", "Giá"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        cartTable = new JTable(tableModel);
        cartTable.setRowHeight(40);
        cartTable.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        cartTable.setForeground(Color.WHITE);
        cartTable.setBackground(new Color(30, 30, 30));
        cartTable.setSelectionBackground(new Color(60, 80, 160));
        cartTable.setSelectionForeground(Color.WHITE);
        cartTable.setGridColor(new Color(70, 70, 70));

        JTableHeader header = cartTable.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 14));
        header.setBackground(new Color(50, 50, 50));
        header.setForeground(Color.WHITE);

        JScrollPane scrollPane = new JScrollPane(cartTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        contentPanel.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setOpaque(false);
        buttonPanel.setBorder(new EmptyBorder(15, 10, 20, 10));
        btnBack = createAnimatedButton("⬅ Quay lại");
        btnRemove = createAnimatedButton("🗑 Xóa khỏi giỏ");
        btnCheckout = createAnimatedButton("💳 Thanh toán");
        btnFavorites = createAnimatedButton("❤️ Yêu thích");

        buttonPanel.add(btnBack);
        buttonPanel.add(btnRemove);
        buttonPanel.add(btnCheckout);
        buttonPanel.add(btnFavorites);
        contentPanel.add(buttonPanel, BorderLayout.SOUTH);

        btnBack.addActionListener(e -> dispose());

        btnRemove.addActionListener(e -> {
            int selectedRow = cartTable.getSelectedRow();
            if (selectedRow != -1) {
                tableModel.removeRow(selectedRow);
            } else {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn sản phẩm để xóa.");
            }
        });

        btnCheckout.addActionListener(e -> {
            double total = 0;
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                int qty = Integer.parseInt(tableModel.getValueAt(i, 1).toString());
                double price = Double.parseDouble(tableModel.getValueAt(i, 2).toString());
                total += qty * price;
            }

            CheckoutView checkoutView = new CheckoutView(total);
            checkoutView.setLocationRelativeTo(this);
            checkoutView.setVisible(true);
            this.setVisible(false);
        });

        btnFavorites.addActionListener(e -> {
            int[] selectedRows = cartTable.getSelectedRows();
            if (selectedRows.length == 0) {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn sản phẩm để yêu thích!");
                return;
            }
            List<String> favorites = new java.util.ArrayList<>();
            for (int row : selectedRows) {
                String productName = tableModel.getValueAt(row, 0).toString();
                favorites.add(productName);
            }
            FavoriteManager.addFavorites(favorites);
            JOptionPane.showMessageDialog(this, "Đã thêm vào yêu thích: " + favorites);
        });

        new javax.swing.Timer(120, e -> {
            colorIndex = (colorIndex + 1) % gradientColors.length;
            contentPanel.setBorder(BorderFactory.createLineBorder(gradientColors[colorIndex], 3));
            repaint();
        }).start();

        setContentPane(contentPanel);
        setVisible(true);

        loadSampleData();
    }

    private void loadSampleData() {
        for (int i = 1; i <= 10; i++) {
            String productName = "Sản phẩm " + i;
            int quantity = (i % 5) + 1;
            String price = String.format("%d0000", (i * 1000));
            tableModel.addRow(new Object[]{productName, quantity, price});
        }
    }

    private JButton createAnimatedButton(String text) {
        JButton button = new JButton(text) {
            private final Color[] buttonColors = {
                new Color(0x00BCD4), new Color(0xFF4081), new Color(0x8BC34A)
            };
            private int index = 0;

            {
                new javax.swing.Timer(150, e -> {
                    index = (index + 1) % buttonColors.length;
                    setBorder(BorderFactory.createLineBorder(buttonColors[index], 2));
                    repaint();
                }).start();
            }
        };
        button.setFont(new Font("Segoe UI", Font.BOLD, 13));
        button.setBackground(new Color(35, 35, 35));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setPreferredSize(new Dimension(150, 38));
        return button;
    }

    private class AnimatedGridPanel extends JPanel {
        private int offset = 0;

        public AnimatedGridPanel() {
            setBackground(new Color(20, 20, 20));
            new javax.swing.Timer(100, e -> {
                offset = (offset + 1) % 40;
                repaint();
            }).start();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.setColor(new Color(70, 70, 70, 90));
            for (int x = -offset; x < getWidth(); x += 40) {
                g.drawLine(x, 0, x, getHeight());
            }
            for (int y = -offset; y < getHeight(); y += 40) {
                g.drawLine(0, y, getWidth(), y);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ShoppingCartApp::new);
    }
}
