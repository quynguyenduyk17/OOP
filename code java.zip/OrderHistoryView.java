package do_an.ui;

import do_an.DBConnection;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.io.FileWriter;
import java.sql.*;
import java.util.*;
import java.util.List;

public class OrderHistoryView extends JFrame {
    private JTable tableOrderHistory;
    private DefaultTableModel model;
    private JLabel lblTotalAmount;
    private JTextField txtSearch;
    private JComboBox<String> cboOrderFilter;
    private JButton btnExportCSV, btnPrevPage, btnNextPage;
    private JLabel lblPageInfo;

    private Color backgroundColor = new Color(30, 30, 60);
    private Color textColor = Color.WHITE;

    // Phân trang
    private int currentPage = 1;
    private int rowsPerPage = 15;
    private List<OrderItemDisplay> fullOrderItems = new ArrayList<>();

    public OrderHistoryView() {
        setTitle("Lịch sử đơn hàng");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        initComponents();
        loadOrderItemsFromDB();
    }

    private void initComponents() {
        JPanel contentPane = new JPanel(new BorderLayout(15, 15));
        contentPane.setBackground(backgroundColor);

        // Panel trên: tìm kiếm + lọc + nút xuất CSV
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.setBackground(backgroundColor);

        JLabel lbSearch = new JLabel("Tìm kiếm sản phẩm:");
        lbSearch.setForeground(textColor);
        topPanel.add(lbSearch);

        txtSearch = new JTextField(20);
        topPanel.add(txtSearch);

        topPanel.add(Box.createHorizontalStrut(20));
        JLabel lbFilter = new JLabel("Lọc theo đơn hàng:");
        lbFilter.setForeground(textColor);
        topPanel.add(lbFilter);

        cboOrderFilter = new JComboBox<>();
        cboOrderFilter.addItem("Tất cả đơn hàng");
        topPanel.add(cboOrderFilter);

        btnExportCSV = new JButton("Xuất CSV");
        topPanel.add(btnExportCSV);

        contentPane.add(topPanel, BorderLayout.NORTH);

        // Bảng dữ liệu đơn hàng
        String[] columns = {"Mã đơn hàng", "Sản phẩm", "Số lượng", "Giá", "Thành tiền"};
        model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false; // không cho sửa bảng
            }
        };

        tableOrderHistory = new JTable(model);
        tableOrderHistory.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        tableOrderHistory.setRowHeight(28);
        tableOrderHistory.setBackground(backgroundColor);
        tableOrderHistory.setForeground(textColor);
        tableOrderHistory.setShowGrid(true);
        tableOrderHistory.setGridColor(Color.getHSBColor(0f, 1f, 1f));
        tableOrderHistory.setSelectionBackground(new Color(70, 130, 180));
        JTableHeader header = tableOrderHistory.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 16));
        header.setForeground(textColor);
        header.setBackground(new Color(50, 50, 90));
        tableOrderHistory.setIntercellSpacing(new Dimension(1, 1));
        tableOrderHistory.setAutoCreateRowSorter(true);

        // Đặt renderer cho cell để màu sắc đồng bộ
        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table,
                                                           Object value, boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (isSelected) {
                    c.setBackground(table.getSelectionBackground());
                    c.setForeground(table.getSelectionForeground());
                } else {
                    c.setBackground(table.getBackground());
                    c.setForeground(table.getForeground());
                }
                ((JComponent) c).setBorder(BorderFactory.createLineBorder(table.getGridColor()));
                return c;
            }
        };
        for (int i = 0; i < tableOrderHistory.getColumnCount(); i++) {
            tableOrderHistory.getColumnModel().getColumn(i).setCellRenderer(renderer);
        }

        JScrollPane scrollPane = new JScrollPane(tableOrderHistory);
        scrollPane.getViewport().setBackground(backgroundColor);
        scrollPane.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY));
        contentPane.add(scrollPane, BorderLayout.CENTER);

        // Panel dưới: tổng tiền và phân trang
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setBackground(backgroundColor);

        lblTotalAmount = new JLabel("Tổng tiền tất cả đơn: 0 đ");
        lblTotalAmount.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTotalAmount.setForeground(Color.YELLOW);
        bottomPanel.add(lblTotalAmount, BorderLayout.WEST);

        JPanel pagingPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        pagingPanel.setBackground(backgroundColor);
        btnPrevPage = new JButton("<< Trước");
        btnNextPage = new JButton("Sau >>");
        lblPageInfo = new JLabel("Trang 1");
        lblPageInfo.setForeground(textColor);

        pagingPanel.add(btnPrevPage);
        pagingPanel.add(lblPageInfo);
        pagingPanel.add(btnNextPage);
        bottomPanel.add(pagingPanel, BorderLayout.EAST);

        contentPane.add(bottomPanel, BorderLayout.SOUTH);

        setContentPane(contentPane);

        addListeners();
    }

    private void addListeners() {
        txtSearch.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                currentPage = 1; // reset trang khi tìm kiếm
                filterAndDisplay();
            }
        });

        cboOrderFilter.addActionListener(e -> {
            currentPage = 1; // reset trang khi đổi filter
            filterAndDisplay();
        });

        btnExportCSV.addActionListener(e -> exportCSV());

        btnPrevPage.addActionListener(e -> {
            if (currentPage > 1) {
                currentPage--;
                filterAndDisplay();
            }
        });

        btnNextPage.addActionListener(e -> {
            int maxPage = (int) Math.ceil(fullOrderItems.size() * 1.0 / rowsPerPage);
            if (currentPage < maxPage) {
                currentPage++;
                filterAndDisplay();
            }
        });
    }

    private void loadOrderItemsFromDB() {
        fullOrderItems.clear();
        Set<String> orderIds = new TreeSet<>();

        String sql = "SELECT oi.order_id, p.product_name, oi.price, oi.quantity " +
                "FROM order_items oi " +
                "JOIN products p ON oi.product_id = p.product_id";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                String orderId = rs.getString("order_id");
                String productName = rs.getString("product_name");
                float price = rs.getFloat("price");
                int quantity = rs.getInt("quantity");

                fullOrderItems.add(new OrderItemDisplay(orderId, productName, quantity, price));
                orderIds.add(orderId);
            }

            // cập nhật combo box lọc đơn hàng
            cboOrderFilter.removeAllItems();
            cboOrderFilter.addItem("Tất cả đơn hàng");
            for (String id : orderIds) {
                cboOrderFilter.addItem(id);
            }

            currentPage = 1;
            filterAndDisplay();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, " " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void filterAndDisplay() {
        String searchText = txtSearch.getText().trim().toLowerCase();
        String selectedOrder = (String) cboOrderFilter.getSelectedItem();

        List<OrderItemDisplay> filtered = new ArrayList<>();
        for (OrderItemDisplay item : fullOrderItems) {
            boolean matchesSearch = item.productName.toLowerCase().contains(searchText);
            boolean matchesOrder = selectedOrder.equals("Tất cả đơn hàng") || item.orderId.equals(selectedOrder);

            if (matchesSearch && matchesOrder) {
                filtered.add(item);
            }
        }

        double totalAmount = 0;
        for (OrderItemDisplay item : filtered) {
            totalAmount += item.price * item.quantity;
        }
        lblTotalAmount.setText(String.format("Tổng tiền tất cả đơn: %.0f đ", totalAmount));

        int totalRows = filtered.size();
        int maxPage = (int) Math.ceil(totalRows * 1.0 / rowsPerPage);
        if (currentPage > maxPage) currentPage = maxPage == 0 ? 1 : maxPage;

        int start = (currentPage - 1) * rowsPerPage;
        int end = Math.min(start + rowsPerPage, totalRows);

        model.setRowCount(0);
        for (int i = start; i < end; i++) {
            OrderItemDisplay item = filtered.get(i);
            model.addRow(new Object[]{
                    item.orderId,
                    item.productName,
                    item.quantity,
                    String.format("%.0f đ", item.price),
                    String.format("%.0f đ", item.price * item.quantity)
            });
        }
        lblPageInfo.setText("Trang " + currentPage + " / " + (maxPage == 0 ? 1 : maxPage));
    }

    private void exportCSV() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Lưu file CSV");
        fileChooser.setFileFilter(new FileNameExtensionFilter("CSV Files", "csv"));
        int userSelection = fileChooser.showSaveDialog(this);
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            try (FileWriter writer = new FileWriter(fileChooser.getSelectedFile() + ".csv")) {
                // Header
                writer.append("Mã đơn hàng,Sản phẩm,Số lượng,Giá,Thành tiền\n");

                for (int i = 0; i < model.getRowCount(); i++) {
                    for (int j = 0; j < model.getColumnCount(); j++) {
                        writer.append(model.getValueAt(i, j).toString());
                        if (j < model.getColumnCount() - 1) writer.append(",");
                    }
                    writer.append("\n");
                }
                JOptionPane.showMessageDialog(this, "✅ Xuất CSV thành công!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, " " + ex.getMessage());
            }
        }
    }

    // Hàm mới để thêm dữ liệu đơn hàng từ bên ngoài (đồng bộ)
    // orderItems: danh sách Object[] mỗi phần tử là {mã sản phẩm, số lượng, giá, thành tiền}
    // Các tham số khác là thông tin khách hàng, thanh toán, v.v.
    public void addOrderData(List<Object[]> orderItems, String customerName, String phone, String address, String paymentMethod, String totalPayment) {
        model.setRowCount(0); // xóa bảng hiện tại
        for (Object[] row : orderItems) {
            model.addRow(row);
        }

        // Hiển thị thông tin đơn hàng dưới dạng hộp thoại
        JOptionPane.showMessageDialog(this,
                "Khách hàng: " + customerName + "\n" +
                "SĐT: " + phone + "\n" +
                "Địa chỉ: " + address + "\n" +
                "Phương thức thanh toán: " + paymentMethod + "\n" +
                "Tổng thanh toán: " + totalPayment,
                "Đơn hàng mới", JOptionPane.INFORMATION_MESSAGE);
    }

    static class OrderItemDisplay {
        String orderId;
        String productName;
        int quantity;
        float price;

        public OrderItemDisplay(String orderId, String productName, int quantity, float price) {
            this.orderId = orderId;
            this.productName = productName;
            this.quantity = quantity;
            this.price = price;
        }
    }

    public void refreshOrderHistory() {
        loadOrderItemsFromDB();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new OrderHistoryView().setVisible(true));
    }
}
