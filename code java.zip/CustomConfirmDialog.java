package do_an.ui;

import javax.swing.*;
import javax.swing.border.AbstractBorder;
import java.awt.*;

public class CustomConfirmDialog extends JDialog {
    private boolean confirmed = false;

    public CustomConfirmDialog(JFrame parent, String message) {
        super(parent, "Xác nhận", true);
        setSize(450, 200);
        setLocationRelativeTo(parent);
        setUndecorated(true);

        // Panel chính với gradient background
        JPanel contentPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                GradientPaint gp = new GradientPaint(0, 0, new Color(30, 144, 255), 0, getHeight(), new Color(10, 50, 100));
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
                super.paintComponent(g);
            }
        };
        contentPanel.setLayout(new BorderLayout());
        contentPanel.setBorder(BorderFactory.createLineBorder(new Color(30, 144, 255), 3));
        contentPanel.setOpaque(false);

        JLabel lblMessage = new JLabel(message, SwingConstants.CENTER);
        lblMessage.setFont(new Font("Segoe UI", Font.BOLD, 24)); // tăng font chữ lớn hơn
        lblMessage.setForeground(Color.WHITE);
        lblMessage.setBorder(BorderFactory.createEmptyBorder(30, 10, 30, 10));

        JPanel buttonPanel = new JPanel();
        buttonPanel.setOpaque(false);
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 50, 10)); // tăng khoảng cách giữa nút

        JButton btnYes = new JButton("Có");
        styleButton(btnYes, new Color(60, 179, 113)); // màu xanh lá dễ nhìn, nhẹ nhàng
        btnYes.setPreferredSize(new Dimension(130, 60)); // tăng kích thước nút
        btnYes.addActionListener(e -> {
            confirmed = true;
            dispose();
        });

        JButton btnNo = new JButton("Không");
        styleButton(btnNo, new Color(220, 20, 60)); // màu đỏ dịu hơn, không quá chói
        btnNo.setPreferredSize(new Dimension(130, 60)); // tăng kích thước nút
        btnNo.addActionListener(e -> {
            confirmed = false;
            dispose();
        });

        buttonPanel.add(btnYes);
        buttonPanel.add(btnNo);

        contentPanel.add(lblMessage, BorderLayout.CENTER);
        contentPanel.add(buttonPanel, BorderLayout.SOUTH);

        setContentPane(contentPanel);
    }

    private void styleButton(JButton btn, Color baseColor) {
        btn.setFont(new Font("Segoe UI", Font.BOLD, 20)); // font lớn hơn
        btn.setForeground(Color.WHITE);
        btn.setBackground(baseColor);
        btn.setFocusPainted(false);
        btn.setBorder(new RoundedAnimatedBorder(baseColor, 3, 16, btn)); // viền bo tròn lớn hơn
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setOpaque(true);
        btn.setContentAreaFilled(true);

        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn.setBackground(baseColor.brighter());
                btn.setForeground(Color.BLACK);
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setBackground(baseColor);
                btn.setForeground(Color.WHITE);
            }
        });
    }

    public boolean isConfirmed() {
        return confirmed;
    }

    public static boolean showConfirmExit(JFrame parent) {
        CustomConfirmDialog dialog = new CustomConfirmDialog(parent, "Bạn có chắc muốn thoát chương trình?");
        dialog.setVisible(true);
        return dialog.isConfirmed();
    }
}

// Class viền nút chuyển động màu gradient
class RoundedAnimatedBorder extends AbstractBorder {
    private final int thickness;
    private final int radius;
    private float hue = 0f;
    private final Color baseColor;
    private final JComponent c;
    private Timer timer;

    public RoundedAnimatedBorder(Color baseColor, int thickness, int radius, JComponent c) {
        this.thickness = thickness;
        this.radius = radius;
        this.baseColor = baseColor;
        this.c = c;

        timer = new Timer(40, e -> {
            hue += 0.01f;
            if (hue > 1f) hue = 0f;
            c.repaint();
        });
        timer.start();
    }

    @Override
    public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
        Graphics2D g2 = (Graphics2D) g.create();

        Color color1 = Color.getHSBColor(hue, 0.8f, 1f);
        Color color2 = color1.darker();

        GradientPaint gp = new GradientPaint(x, y, color1, x + width, y + height, color2);

        g2.setPaint(gp);
        g2.setStroke(new BasicStroke(thickness));
        g2.drawRoundRect(x + thickness / 2, y + thickness / 2,
                         width - thickness, height - thickness, radius, radius);

        g2.dispose();
    }
}
