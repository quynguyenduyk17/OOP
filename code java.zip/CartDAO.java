package do_an.dao;

import do_an.DBConnection;
import do_an.model.CartItem;
import do_an.model.Product;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CartDAO {

    public void addProductToCart(int userId, Product product, int quantity) {
        String sql = "INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ps.setString(2, product.getProductId());
            ps.setInt(3, quantity);

            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<CartItem> getCartItems(int userId) {
        List<CartItem> cartItems = new ArrayList<>();
        String sql = "SELECT p.*, c.quantity FROM cart c JOIN products p ON c.product_id = p.product_id WHERE c.user_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Product product = new Product(
                    rs.getString("product_id"),
                    rs.getString("product_name"),
                    rs.getDouble("price"),
                    rs.getString("category"),
                    rs.getInt("stock_quantity"),
                    rs.getString("seller_id")
                );

                int quantity = rs.getInt("quantity");
                cartItems.add(new CartItem(product, quantity));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return cartItems;
    }

    public void removeProductFromCart(int userId, String productId) {
        String sql = "DELETE FROM cart WHERE user_id = ? AND product_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ps.setString(2, productId);

            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
