package do_an.ui;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class CheckoutView extends JFrame {
    private JTable tableOrderDetails;
    private JLabel lblTotal;
    private JButton btnPlaceOrder, btnDiscountCode;

    // Thêm label hiển thị thuế, phí vận chuyển, tổng thanh toán
    private JLabel lblTax, lblShippingFee, lblFinalTotal;

    // Thêm các trường nhập thông tin khách hàng
    private JTextField txtCustomerName, txtCustomerPhone;
    private JTextArea txtCustomerAddress;

    // Combo box chọn phương thức thanh toán
    private JComboBox<String> cbPaymentMethod;

    private Color gridColor = Color.getHSBColor(0f, 1f, 1f);
    private float colorPhase = 0f;
    private Timer gridTimer;
    private Timer borderTimer;

    private JPanel contentPanel;
    private double currentDiscountAmount = 0;
    private List<Object[]> currentItems = new ArrayList<>();

    // Thuế 10% và phí vận chuyển cố định
    private final double TAX_RATE = 0.10;
    private final double SHIPPING_FEE = 30000;

    public CheckoutView() {
        setTitle("Checkout - Thanh toán");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        initComponents();
        startGridAnimation();
        startBorderAnimation();

        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                if (gridTimer != null) gridTimer.stop();
                if (borderTimer != null) borderTimer.stop();
            }
        });

        btnPlaceOrder.addActionListener(e -> placeOrder());
        btnDiscountCode.addActionListener(e -> openDiscountDialog());
    }
//
    public CheckoutView(double total) {
        this(); // gọi constructor mặc định
        lblTotal.setText("Tổng tiền hàng: " + String.format("%.0f đ", total));
        updateTotals(); // cập nhật thuế phí, tổng cuối (nếu muốn)
    }
//    
    private void initComponents() {
        Color backgroundColor = new Color(30, 30, 60);
        Color textColor = Color.WHITE;

        JPanel contentPane = new JPanel(new BorderLayout(15, 15));
        contentPane.setBackground(backgroundColor);

        // Bảng hiển thị đơn hàng
        String[] columns = {"Sản phẩm", "Số lượng", "Giá", "Thành tiền"};
        DefaultTableModel model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tableOrderDetails = new JTable(model);
        tableOrderDetails.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        tableOrderDetails.setRowHeight(28);
        tableOrderDetails.setBackground(backgroundColor);
        tableOrderDetails.setForeground(textColor);
        tableOrderDetails.setShowGrid(true);
        tableOrderDetails.setGridColor(gridColor);
        tableOrderDetails.setSelectionBackground(new Color(70, 130, 180));
        tableOrderDetails.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 16));
        tableOrderDetails.getTableHeader().setForeground(textColor);
        tableOrderDetails.getTableHeader().setBackground(new Color(50, 50, 90));
        tableOrderDetails.setIntercellSpacing(new Dimension(1, 1));

        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table,
                                                           Object value, boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                c.setBackground(table.getBackground());
                c.setForeground(table.getForeground());
                ((JComponent) c).setBorder(BorderFactory.createLineBorder(table.getGridColor()));
                return c;
            }
        };
        for (int i = 0; i < tableOrderDetails.getColumnCount(); i++) {
            tableOrderDetails.getColumnModel().getColumn(i).setCellRenderer(renderer);
        }

        JScrollPane scrollPane = new JScrollPane(tableOrderDetails);
        scrollPane.getViewport().setBackground(backgroundColor);
        scrollPane.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY));
        contentPane.add(scrollPane, BorderLayout.CENTER);

        // Panel bên phải để nhập thông tin khách hàng và chọn thanh toán
        JPanel infoPanel = new JPanel();
        infoPanel.setBackground(backgroundColor);
        infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
        infoPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.GRAY), "Thông tin khách hàng & Thanh toán", 0, 0, new Font("Segoe UI", Font.BOLD, 18), Color.YELLOW));

        // Tên khách hàng
        JLabel lblName = new JLabel("Họ tên khách hàng:");
        lblName.setForeground(textColor);
        lblName.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        txtCustomerName = new JTextField();
        txtCustomerName.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        infoPanel.add(lblName);
        infoPanel.add(txtCustomerName);
        infoPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        // SĐT khách hàng
        JLabel lblPhone = new JLabel("Số điện thoại:");
        lblPhone.setForeground(textColor);
        lblPhone.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        txtCustomerPhone = new JTextField();
        txtCustomerPhone.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        infoPanel.add(lblPhone);
        infoPanel.add(txtCustomerPhone);
        infoPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        // Địa chỉ khách hàng
        JLabel lblAddress = new JLabel("Địa chỉ giao hàng:");
        lblAddress.setForeground(textColor);
        lblAddress.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        txtCustomerAddress = new JTextArea(4, 20);
        txtCustomerAddress.setLineWrap(true);
        txtCustomerAddress.setWrapStyleWord(true);
        txtCustomerAddress.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        JScrollPane addressScroll = new JScrollPane(txtCustomerAddress);
        addressScroll.setMaximumSize(new Dimension(Integer.MAX_VALUE, 80));
        infoPanel.add(lblAddress);
        infoPanel.add(addressScroll);
        infoPanel.add(Box.createRigidArea(new Dimension(0, 15)));

        // Phương thức thanh toán
        JLabel lblPayment = new JLabel("Phương thức thanh toán:");
        lblPayment.setForeground(textColor);
        lblPayment.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        cbPaymentMethod = new JComboBox<>(new String[]{"Tiền mặt", "Thẻ tín dụng", "Ví điện tử"});
        cbPaymentMethod.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        infoPanel.add(lblPayment);
        infoPanel.add(cbPaymentMethod);
        infoPanel.add(Box.createRigidArea(new Dimension(0, 15)));

        // Thuế, phí vận chuyển, tổng cuối
        lblTax = new JLabel("Thuế (10%): 0 đ");
        lblTax.setForeground(Color.ORANGE);
        lblTax.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblShippingFee = new JLabel("Phí vận chuyển: 30,000 đ");
        lblShippingFee.setForeground(Color.ORANGE);
        lblShippingFee.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblFinalTotal = new JLabel("Tổng thanh toán: 0 đ");
        lblFinalTotal.setForeground(Color.YELLOW);
        lblFinalTotal.setFont(new Font("Segoe UI", Font.BOLD, 20));

        infoPanel.add(lblTax);
        infoPanel.add(lblShippingFee);
        infoPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        infoPanel.add(lblFinalTotal);

        contentPane.add(infoPanel, BorderLayout.EAST);

        // Panel dưới cùng với nút
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setBackground(backgroundColor);

        lblTotal = new JLabel("Tổng tiền hàng: 0 đ");
        lblTotal.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTotal.setForeground(Color.YELLOW);
        bottomPanel.add(lblTotal, BorderLayout.WEST);

        JPanel rightButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        rightButtons.setBackground(backgroundColor);

        btnDiscountCode = new JButton("Nhập mã giảm giá");
        btnDiscountCode.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btnDiscountCode.setBackground(new Color(0, 102, 204));
        btnDiscountCode.setForeground(Color.WHITE);
        btnDiscountCode.setFocusPainted(false);
        btnDiscountCode.setPreferredSize(new Dimension(180, 40));
        rightButtons.add(btnDiscountCode);

        btnPlaceOrder = new JButton("Đặt hàng");
        btnPlaceOrder.setFont(new Font("Segoe UI", Font.BOLD, 18));
        btnPlaceOrder.setBackground(new Color(0, 153, 76));
        btnPlaceOrder.setForeground(Color.WHITE);
        btnPlaceOrder.setFocusPainted(false);
        btnPlaceOrder.setPreferredSize(new Dimension(150, 40));
        rightButtons.add(btnPlaceOrder);

        bottomPanel.add(rightButtons, BorderLayout.EAST);

        contentPane.add(bottomPanel, BorderLayout.SOUTH);

        setContentPane(contentPane);
        this.contentPanel = contentPane;
    }

    private void startGridAnimation() {
        gridTimer = new Timer(100, e -> {
            colorPhase += 5;
            if (colorPhase >= 360) colorPhase = 0;
            gridColor = Color.getHSBColor(colorPhase / 360f, 1f, 1f);
            tableOrderDetails.setGridColor(gridColor);
            tableOrderDetails.repaint();
            tableOrderDetails.getTableHeader().repaint();
        });
        gridTimer.start();
    }

    private void startBorderAnimation() {
        borderTimer = new Timer(100, e -> {
            Color borderColor = Color.getHSBColor(colorPhase / 360f, 1f, 1f);
            Border coloredBorder = BorderFactory.createLineBorder(borderColor, 5, true);
            contentPanel.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createEmptyBorder(15, 15, 15, 15),
                    coloredBorder
            ));
            contentPanel.repaint();
        });
        borderTimer.start();
    }

    public void setOrderDetails(List<Object[]> items) {
        currentItems = items;

        DefaultTableModel model = (DefaultTableModel) tableOrderDetails.getModel();
        model.setRowCount(0);

        for (Object[] item : items) {
            String tenSP = (String) item[0];
            int soLuong = (int) item[1];
            double gia = (double) item[2];
            double thanhTien = soLuong * gia;

            model.addRow(new Object[]{
                    tenSP,
                    soLuong,
                    String.format("%.0f đ", gia),
                    String.format("%.0f đ", thanhTien)
            });
        }

        updateTotals();
    }

    // Cập nhật tổng tiền, thuế, phí và tổng cuối
    private void updateTotals() {
        double total = 0;
        for (Object[] item : currentItems) {
            int soLuong = (int) item[1];
            double gia = (double) item[2];
            total += soLuong * gia;
        }

        if (currentDiscountAmount > 0) {
            total -= currentDiscountAmount;
            if (total < 0) total = 0;
        }

        double tax = total * TAX_RATE;
        double finalTotal = total + tax + SHIPPING_FEE;

        lblTotal.setText("Tổng tiền hàng: " + String.format("%.0f đ", total));
        lblTax.setText("Thuế (10%): " + String.format("%.0f đ", tax));
        lblShippingFee.setText("Phí vận chuyển: " + String.format("%.0f đ", SHIPPING_FEE));
        lblFinalTotal.setText("Tổng thanh toán: " + String.format("%.0f đ", finalTotal));
    }

    public void loadDataFromDB() {
        List<Object[]> data = new ArrayList<>();

        try (Connection conn = do_an.DBConnection.getConnection()) {
            String sql = "SELECT p.product_name, oi.quantity, oi.price " +
                    "FROM order_items oi JOIN products p ON oi.product_id = p.product_id";

            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String tenSP = rs.getString("product_name");
                int soLuong = rs.getInt("quantity");
                double gia = rs.getDouble("price");

                data.add(new Object[]{tenSP, soLuong, gia});
            }

            setOrderDetails(data);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "❌ Lỗi khi tải dữ liệu từ database:\n" + e.getMessage());
            e.printStackTrace();
        }
    }

    private void showQRCodeDialog() {
        QRCodeDialog.showDialog(this);
    }

    private void openDiscountDialog() {
        DiscountCodeDialog[] dialogRef = new DiscountCodeDialog[1]; // tạo mảng 1 phần tử để "bypass" hiệu ứng final

        dialogRef[0] = new DiscountCodeDialog(this, e -> {
            currentDiscountAmount = dialogRef[0].getDiscountAmount();
            updateTotals();
        });

        dialogRef[0].setVisible(true);
    }

   
//    private void placeOrder() {
//        String name = txtCustomerName.getText().trim();
//        String phone = txtCustomerPhone.getText().trim();
//        String address = txtCustomerAddress.getText().trim();
//        String paymentMethod = (String) cbPaymentMethod.getSelectedItem();
//
//        // Kiểm tra thông tin khách hàng
//        if (name.isEmpty()) {
//            JOptionPane.showMessageDialog(this, "Vui lòng nhập họ tên khách hàng!", "Thông báo", JOptionPane.WARNING_MESSAGE);
//            txtCustomerName.requestFocus();
//            return;
//        }
//        if (phone.isEmpty()) {
//            JOptionPane.showMessageDialog(this, "Vui lòng nhập số điện thoại!", "Thông báo", JOptionPane.WARNING_MESSAGE);
//            txtCustomerPhone.requestFocus();
//            return;
//        }
//        if (address.isEmpty()) {
//            JOptionPane.showMessageDialog(this, "Vui lòng nhập địa chỉ giao hàng!", "Thông báo", JOptionPane.WARNING_MESSAGE);
//            txtCustomerAddress.requestFocus();
//            return;
//        }
//
//        if (currentItems.isEmpty()) {
//            JOptionPane.showMessageDialog(this, "Giỏ hàng đang trống!", "Thông báo", JOptionPane.WARNING_MESSAGE);
//            return;
//        }
//
//        // Tổng cuối có thuế, phí
//        double total = 0;
//        for (Object[] item : currentItems) {
//            int soLuong = (int) item[1];
//            double gia = (double) item[2];
//            total += soLuong * gia;
//        }
//        if (currentDiscountAmount > 0) {
//            total -= currentDiscountAmount;
//            if (total < 0) total = 0;
//        }
//        double tax = total * TAX_RATE;
//        double finalTotal = total + tax + SHIPPING_FEE;
//
//        // Hiển thị xác nhận đơn hàng
//        String message = String.format(
//                "Xác nhận đặt hàng:\n\nKhách hàng: %s\nSĐT: %s\nĐịa chỉ: %s\nPhương thức thanh toán: %s\n\nTổng tiền hàng: %.0f đ\nThuế (10%%): %.0f đ\nPhí vận chuyển: %.0f đ\nGiảm giá: %.0f đ\n\nTổng thanh toán: %.0f đ\n\nBạn có muốn đặt hàng không?",
//                name, phone, address, paymentMethod, total, tax, SHIPPING_FEE, currentDiscountAmount, finalTotal);
//
//        int confirm = JOptionPane.showConfirmDialog(this, message, "Xác nhận đặt hàng", JOptionPane.YES_NO_OPTION);
//        if (confirm == JOptionPane.YES_OPTION) {
//            // Lưu đơn hàng vào DB (nếu cần) tại đây
//
//            JOptionPane.showMessageDialog(this, "✅ Đặt hàng thành công! Cảm ơn quý khách.");
//            new OrderHistoryView().setVisible(true);
//
//            // Hiển thị mã QR code để khách hàng quét thanh toán
//            showQRCodeDialog();
//
//            // Đóng form thanh toán
//            this.dispose();
//        }
//    }
//}
 // Thêm hàm trả dữ liệu đơn hàng hiện tại
    public List<Object[]> getCurrentOrderData() {
        // Trả về bản sao để tránh thay đổi dữ liệu bên ngoài
        return new ArrayList<>(currentItems);
    }

    // Sửa lại phần xử lý đặt hàng thành công
    private void placeOrder() {
        String name = txtCustomerName.getText().trim();
        String phone = txtCustomerPhone.getText().trim();
        String address = txtCustomerAddress.getText().trim();
        String paymentMethod = (String) cbPaymentMethod.getSelectedItem();

        if (name.isEmpty() || phone.isEmpty() || address.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ thông tin khách hàng.");
            return;
        }

        if (currentItems.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Đơn hàng trống.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
                "Xác nhận đặt hàng cho khách: " + name + "\nTổng thanh toán: " + lblFinalTotal.getText(),
                "Xác nhận", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            // TODO: Lưu thông tin đơn hàng vào DB

            JOptionPane.showMessageDialog(this, "Đặt hàng thành công!");
            QRCodeDialog.showDialog(this);
            this.dispose();
            
            // Đồng bộ dữ liệu đơn hàng vừa đặt sang OrderHistoryView
            OrderHistoryView orderHistoryView = new OrderHistoryView();

            // Giả sử OrderHistoryView có phương thức addOrderData nhận List<Object[]>
            orderHistoryView.addOrderData(getCurrentOrderData(), name, phone, address, paymentMethod, lblFinalTotal.getText());

            orderHistoryView.setVisible(true);
        }
    }
}