package do_an.ui;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.net.URL;
import java.util.ArrayList;

public class Trang_chu extends JFrame {
    private JPanel sidebar;
    private JLabel imageLabel;
    private JButton activeButton = null;
    private float hue = 0f; // Biến hue dùng cho gradient chuyển động

    private boolean isLoggedIn = false;
    private java.util.List<JButton> restrictedButtons = new ArrayList<>();

    public Trang_chu() {
        setTitle("Trang chủ");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH); // Fullscreen
        setUndecorated(true); // Ẩn thanh tiêu đề nếu muốn

        setLayout(new BorderLayout());

        // Kích thước màn hình
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int screenWidth = screenSize.width;
        int screenHeight = screenSize.height;

        // Sidebar gradient động với hue chuyển động
        sidebar = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();
                Color color1 = Color.getHSBColor(hue, 0.6f, 0.6f);
                Color color2 = Color.getHSBColor((hue + 0.2f) % 1f, 0.6f, 0.6f);
                GradientPaint gp = new GradientPaint(0, 0, color1, 0, getHeight(), color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
                g2d.dispose();
            }
        };

        Timer sidebarAnim = new Timer(40, e -> {
            hue += 0.005f;
            if (hue > 1f) hue = 0f;
            sidebar.repaint();
        });
        sidebarAnim.start();

        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        int sidebarWidth = screenWidth / 3;
        sidebar.setPreferredSize(new Dimension(sidebarWidth, screenHeight));

        // Logo text "CHÀO MỪNG BẠN"
        JLabel lblLogo = new JLabel(" WELCOME ");
        lblLogo.setForeground(new Color(0, 255, 255));
        lblLogo.setFont(new Font(" Times New Roman ", Font.BOLD, 36));
        lblLogo.setAlignmentX(Component.CENTER_ALIGNMENT);
        lblLogo.setBorder(new EmptyBorder(30, 20, 20, 20));
        sidebar.add(lblLogo);

        // Thêm ảnh logo ngay sau dòng text
        URL logoUrl = getClass().getResource("/do_an/resources/logo.jpg");
        if (logoUrl != null) {
            ImageIcon logoIcon = new ImageIcon(logoUrl);
            Image scaledLogo = logoIcon.getImage().getScaledInstance(639, 210, Image.SCALE_SMOOTH);
            JLabel logoLabel = new JLabel(new ImageIcon(scaledLogo));
            logoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            logoLabel.setBorder(new EmptyBorder(10, 10, 30, 10));
            sidebar.add(logoLabel);
        } else {
            JLabel logoLabel = new JLabel("Không tìm thấy logo", SwingConstants.CENTER);
            logoLabel.setForeground(Color.RED);
            logoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            sidebar.add(logoLabel);
        }

        // Hiệu ứng mờ dần
        Timer fadeTimer = new Timer(50, null);
        fadeTimer.addActionListener(new ActionListener() {
            float alpha = 0f;
            public void actionPerformed(ActionEvent e) {
                alpha += 0.05f;
                lblLogo.setForeground(new Color(0f, 1f, 1f, Math.min(alpha, 1f)));
                if (alpha >= 1f) fadeTimer.stop();
            }
        });
        fadeTimer.start();

        sidebar.add(Box.createVerticalGlue());

        // Các nút sidebar:
        // Nút "Đăng nhập" luôn enabled
        JButton btnDangNhap = createSidebarButton("Đăng nhập", () -> openChildForm(new LoginForm(this)));
        sidebar.add(btnDangNhap);
        sidebar.add(Box.createVerticalStrut(25));

        // Các nút còn lại thêm vào danh sách restrictedButtons để disable khi chưa đăng nhập
        JButton btnMuaSam = createSidebarButton("Mua sắm", () -> openChildForm(new CustomerDashboard()));
        restrictedButtons.add(btnMuaSam);
        sidebar.add(btnMuaSam);
        sidebar.add(Box.createVerticalStrut(25));

        JButton btnGioHang = createSidebarButton("Giỏ hàng", () -> openChildForm(new CartView()));
        restrictedButtons.add(btnGioHang);
        sidebar.add(btnGioHang);
        sidebar.add(Box.createVerticalStrut(25));

        JButton btnThanhToan = createSidebarButton("Thanh toán", () -> {
            CheckoutView checkoutView = new CheckoutView();
            checkoutView.loadDataFromDB();
            openChildForm(checkoutView);
        });
        restrictedButtons.add(btnThanhToan);
        sidebar.add(btnThanhToan);
        sidebar.add(Box.createVerticalStrut(25));

        JButton btnQuanTri = createSidebarButton("Quản trị", () -> openChildForm(new AdminDashboard()));
        restrictedButtons.add(btnQuanTri);
        sidebar.add(btnQuanTri);
        sidebar.add(Box.createVerticalStrut(25));

        JButton btnDonHang = createSidebarButton("Đơn hàng đã mua", () -> openChildForm(new OrderHistoryView()));
        restrictedButtons.add(btnDonHang);
        sidebar.add(btnDonHang);
        sidebar.add(Box.createVerticalStrut(25));

        JButton btnYeuThich = createSidebarButton("Yêu thích", () -> openChildForm(new ShoppingCartApp()));
        restrictedButtons.add(btnYeuThich);
        sidebar.add(btnYeuThich);
        sidebar.add(Box.createVerticalStrut(25));

        // Nút Chat hỗ trợ cũng khóa khi chưa đăng nhập
        JButton btnChatHoTro = createSidebarButton("Chat hỗ trợ", () -> openChatSupport());
        restrictedButtons.add(btnChatHoTro);
        sidebar.add(btnChatHoTro);

        sidebar.add(Box.createVerticalGlue());

        // Nút Thoát luôn enabled
        JButton btnThoat = new JButton("Thoát");
        btnThoat.setMaximumSize(new Dimension(300, 60));
        btnThoat.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnThoat.setFocusPainted(false);
        btnThoat.setFont(new Font("Segoe UI", Font.BOLD, 20));
        btnThoat.setForeground(Color.WHITE);
        btnThoat.setBackground(new Color(200, 30, 30));
        btnThoat.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnThoat.setContentAreaFilled(false);
        btnThoat.setOpaque(true);
        btnThoat.setBorder(new CompoundBorder(
                new LineBorder(new Color(255, 100, 100), 2, true),
                new EmptyBorder(15, 20, 15, 20)));

        btnThoat.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btnThoat.setBackground(new Color(255, 70, 70));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                btnThoat.setBackground(new Color(200, 30, 30));
            }
        });

        btnThoat.addActionListener(e -> {
            boolean confirm = CustomConfirmDialog.showConfirmExit(Trang_chu.this);
            if (confirm) {
                System.exit(0);
            }
        });

        sidebar.add(btnThoat);
        sidebar.add(Box.createVerticalStrut(20));

        JPanel imagePanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setColor(new Color(30, 30, 40));
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
            }
        };
        imagePanel.setPreferredSize(new Dimension(screenWidth * 2 / 3, screenHeight));

        URL url = getClass().getResource("/do_an/resources/anhnen.jpg");
        if (url != null) {
            ImageIcon originalIcon = new ImageIcon(url);
            Image scaledImage = originalIcon.getImage().getScaledInstance(
                    imagePanel.getPreferredSize().width,
                    imagePanel.getPreferredSize().height,
                    Image.SCALE_SMOOTH);
            imageLabel = new JLabel(new ImageIcon(scaledImage));
        } else {
            imageLabel = new JLabel("Ảnh không tồn tại", SwingConstants.CENTER);
            imageLabel.setForeground(Color.RED);
        }
        imagePanel.add(imageLabel, BorderLayout.CENTER);

        add(sidebar, BorderLayout.WEST);
        add(imagePanel, BorderLayout.CENTER);

        // Khóa các nút ngay khi mở app
        setLoggedIn(false);
    }

    private JButton createSidebarButton(String text, Runnable onClick) {
        JButton btn = new JButton(text);
        btn.setMaximumSize(new Dimension(300, 60));
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);
        btn.setFocusPainted(false);
        btn.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        btn.setForeground(Color.WHITE);
        btn.setBackground(new Color(18, 18, 25));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setContentAreaFilled(false);
        btn.setOpaque(true);
        btn.setBorder(new CompoundBorder(
                new LineBorder(new Color(0, 255, 255), 2, true),
                new EmptyBorder(15, 20, 15, 20)));

        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if (btn != activeButton) btn.setBackground(new Color(0, 128, 255));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                if (btn != activeButton) btn.setBackground(new Color(18, 18, 25));
            }
        });

        btn.addActionListener(e -> {
            if (!btn.isEnabled()) {
                // Nút bị khóa thì không làm gì
                return;
            }
            if (activeButton != null) {
                activeButton.setBackground(new Color(18, 18, 25));
                activeButton.setForeground(Color.WHITE);
            }
            activeButton = btn;
            btn.setBackground(new Color(0, 255, 255));
            btn.setForeground(Color.BLACK);
            onClick.run();
        });

        return btn;
    }

    private void openChildForm(JFrame childFrame) {
        childFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Đóng chỉ form con thôi
        childFrame.setLocationRelativeTo(this);
        childFrame.setVisible(true);
    }

    // mở giao diện chat .    
    private void openChatSupport() {
        ChatUI chatWindow = new ChatUI();
        chatWindow.setVisible(true);
    }

    // Cập nhật trạng thái đăng nhập và enable/disable nút
    public void setLoggedIn(boolean loggedIn) {
        isLoggedIn = loggedIn;
        for (JButton btn : restrictedButtons) {
            btn.setEnabled(isLoggedIn);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Trang_chu().setVisible(true));
    }
}
