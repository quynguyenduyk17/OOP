package do_an.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class LoginForm extends JFrame {
    private JPanel menuPanel, contentPanel, loginPanel, registerPanel;
    private JButton btnLogin, btnRegister, btnSwitchToLogin, btnSwitchToRegister, btnLogout;
    private JTextField txtUsernameLogin, txtUsernameRegister;
    private JPasswordField txtPasswordLogin, txtPasswordRegister;
    private Trang_chu mainFrame;

    public LoginForm(Trang_chu mainFrame) {
        this.mainFrame = mainFrame;
        setTitle("Đăng nhập / Đăng ký/ Đăng suất");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(800, 500);
        setLocationRelativeTo(null);
        setUndecorated(true);
        setLayout(new BorderLayout());

        initMenuPanel();
        initContentPanel();

        add(menuPanel, BorderLayout.WEST);
        add(contentPanel, BorderLayout.CENTER);

        // Gradient background animation
        new Timer(50, e -> {
            float hue = (System.currentTimeMillis() % 10000) / 10000f;
            menuPanel.setBackground(Color.getHSBColor(hue, 0.4f, 0.4f));
            menuPanel.repaint();
        }).start();

        setVisible(true);
    }

    private void initMenuPanel() {
        menuPanel = new JPanel();
        menuPanel.setPreferredSize(new Dimension(200, getHeight()));
        menuPanel.setLayout(new BoxLayout(menuPanel, BoxLayout.Y_AXIS));
        menuPanel.setBackground(new Color(30, 30, 60));

        btnLogin = new JButton("Đăng nhập");
        btnRegister = new JButton("Đăng ký");
        btnLogout = new JButton("Đăng xuất");

        styleButton(btnLogin);
        styleButton(btnRegister);
        styleButton(btnLogout);

        btnLogin.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
        btnRegister.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
        btnLogout.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));

        btnLogin.addActionListener(e -> switchToLogin());
        btnRegister.addActionListener(e -> switchToRegister());
        btnLogout.addActionListener(e -> handleLogout());

        menuPanel.add(Box.createVerticalGlue());
        menuPanel.add(btnLogin);
        menuPanel.add(Box.createVerticalStrut(10));
        menuPanel.add(btnRegister);
        menuPanel.add(Box.createVerticalStrut(10));
        menuPanel.add(btnLogout);
        menuPanel.add(Box.createVerticalGlue());
    }

    private void initContentPanel() {
        contentPanel = new JPanel(new CardLayout());

        // === LOGIN PANEL ===
        loginPanel = new JPanel(new GridBagLayout());
        loginPanel.setBackground(new Color(245, 245, 245));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 20, 10, 20);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.CENTER;

        // Thêm ảnh logo phía trên
        try {
            ImageIcon icon = new ImageIcon(getClass().getResource("/do_an/resources/logonen.png"));
            Image scaledImage = icon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
            JLabel lblIcon = new JLabel(new ImageIcon(scaledImage));
            loginPanel.add(lblIcon, gbc);
            gbc.gridy++;
        } catch (Exception ex) {
            System.err.println("Không thể tải ảnh logonen.png: " + ex.getMessage());
        }

        txtUsernameLogin = new JTextField(20);
        txtPasswordLogin = new JPasswordField(20);
        addFocusEffect(txtUsernameLogin);
        addFocusEffect(txtPasswordLogin);

        JButton btnSubmitLogin = new JButton("Đăng nhập");
        styleButton(btnSubmitLogin);

        loginPanel.add(new JLabel("Tên đăng nhập:"), gbc);
        gbc.gridy++;
        loginPanel.add(txtUsernameLogin, gbc);
        gbc.gridy++;
        loginPanel.add(new JLabel("Mật khẩu:"), gbc);
        gbc.gridy++;
        loginPanel.add(txtPasswordLogin, gbc);
        gbc.gridy++;
        loginPanel.add(btnSubmitLogin, gbc);

        btnSubmitLogin.addActionListener(e -> {
            String username = txtUsernameLogin.getText();
            String password = new String(txtPasswordLogin.getPassword());

            if (LoginHandler.authenticate(username, password)) {
                JOptionPane.showMessageDialog(this, "Đăng nhập thành công!");
                if (mainFrame != null) mainFrame.setLoggedIn(true);
                dispose();
            } else {
                Point original = getLocation();
                new Thread(() -> {
                    for (int i = 0; i < 10; i++) {
                        try {
                            setLocation(original.x + (i % 2 == 0 ? 10 : -10), original.y);
                            Thread.sleep(30);
                        } catch (InterruptedException ex) {
                            ex.printStackTrace();
                        }
                    }
                    setLocation(original);
                }).start();
                JOptionPane.showMessageDialog(this, "Sai tên đăng nhập hoặc mật khẩu!", "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        });

        // === REGISTER PANEL giữ nguyên ===
        registerPanel = new JPanel(new GridBagLayout());
        registerPanel.setBackground(new Color(235, 235, 250));
        GridBagConstraints gbc2 = new GridBagConstraints();
        gbc2.insets = new Insets(10, 20, 10, 20);
        gbc2.gridx = 0;
        gbc2.gridy = 0;

        txtUsernameRegister = new JTextField(40);
        txtPasswordRegister = new JPasswordField(40);
        addFocusEffect(txtUsernameRegister);
        addFocusEffect(txtPasswordRegister);

        JButton btnSubmitRegister = new JButton("Đăng ký");
        styleButton(btnSubmitRegister);

        registerPanel.add(new JLabel("Tên đăng nhập:"), gbc2);
        gbc2.gridy++;
        registerPanel.add(txtUsernameRegister, gbc2);
        gbc2.gridy++;
        registerPanel.add(new JLabel("Mật khẩu:"), gbc2);
        gbc2.gridy++;
        registerPanel.add(txtPasswordRegister, gbc2);
        gbc2.gridy++;
        registerPanel.add(btnSubmitRegister, gbc2);

        btnSubmitRegister.addActionListener(e -> {
            String username = txtUsernameRegister.getText();
            String password = new String(txtPasswordRegister.getPassword());

            if (LoginHandler.register(username, password)) {
                JOptionPane.showMessageDialog(this, "Đăng ký thành công! Bạn có thể đăng nhập.");
                switchToLogin();
            } else {
                JOptionPane.showMessageDialog(this, "Tên đăng nhập đã tồn tại!", "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        });

        contentPanel.add(loginPanel, "login");
        contentPanel.add(registerPanel, "register");

        new Timer(100, e -> {
            float hue = (System.currentTimeMillis() % 15000) / 15000f;
            contentPanel.setBackground(Color.getHSBColor(hue, 0.15f, 1f));
        }).start();

        switchToLogin();
    }

    private void styleButton(JButton button) {
        button.setFocusPainted(false);
        button.setBackground(new Color(70, 130, 180));
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(60, 60, 60), 1),
            BorderFactory.createEmptyBorder(10, 20, 10, 20)
        ));
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                button.setBackground(new Color(100, 149, 237));
            }

            public void mouseExited(MouseEvent evt) {
                button.setBackground(new Color(70, 130, 180));
            }
        });
        button.addActionListener(e -> {
            button.setBackground(new Color(30, 144, 255));
            new Timer(150, ev -> button.setBackground(new Color(70, 130, 180))).start();
        });
    }

    private void addFocusEffect(JTextField field) {
        field.setBackground(Color.WHITE);
        field.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent evt) {
                field.setBackground(new Color(255, 255, 200));
            }

            public void focusLost(FocusEvent evt) {
                field.setBackground(Color.WHITE);
            }
        });
    }

    private void switchToLogin() {
        CardLayout cl = (CardLayout) contentPanel.getLayout();
        cl.show(contentPanel, "login");
        animatePanelColor(loginPanel, registerPanel.getBackground(), new Color(245, 245, 245));
        loginPanel.setVisible(true);
        registerPanel.setVisible(false);
    }

    private void switchToRegister() {
        CardLayout cl = (CardLayout) contentPanel.getLayout();
        cl.show(contentPanel, "register");
        animatePanelColor(registerPanel, loginPanel.getBackground(), new Color(235, 235, 250));
        registerPanel.setVisible(true);
        loginPanel.setVisible(false);
    }

    private void animatePanelColor(JPanel panel, Color from, Color to) {
        new Thread(() -> {
            for (int i = 0; i <= 100; i++) {
                float ratio = i / 100f;
                int red = (int) (from.getRed() * (1 - ratio) + to.getRed() * ratio);
                int green = (int) (from.getGreen() * (1 - ratio) + to.getGreen() * ratio);
                int blue = (int) (from.getBlue() * (1 - ratio) + to.getBlue() * ratio);
                Color newColor = new Color(red, green, blue);
                SwingUtilities.invokeLater(() -> panel.setBackground(newColor));
                try {
                    Thread.sleep(5);
                } catch (InterruptedException ex) {
                }
            }
        }).start();
    }

    private void handleLogout() {
        int confirm = JOptionPane.showConfirmDialog(this, "Bạn có chắc chắn muốn đăng xuất?", "Xác nhận", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            txtUsernameLogin.setText("");
            txtPasswordLogin.setText("");
            txtUsernameRegister.setText("");
            txtPasswordRegister.setText("");
            switchToLogin();
            if (mainFrame != null) mainFrame.setLoggedIn(false);
            JOptionPane.showMessageDialog(this, "Đăng xuất thành công!");
        }
    }
}
