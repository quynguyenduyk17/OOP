package do_an.ui;

import do_an.dao.UserDAO;
import do_an.model.User;

import javax.swing.*;
import java.awt.*;

public class RegisterForm extends JFrame {
    private JTextField txtUsername;
    private JPasswordField txtPassword;

    private JRadioButton radioAdmin;
    private JRadioButton radioStaff;
    private JRadioButton radioCustomer;
    private ButtonGroup roleGroup;

    private JButton btnRegister;

    public RegisterForm() {
        setTitle("Đăng ký tài khoản mới");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        initComponents();
        addEvents();
    }

    private void initComponents() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();

        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblUsername = new JLabel("Tên đăng nhập:");
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(lblUsername, gbc);

        txtUsername = new JTextField();
        gbc.gridx = 1; gbc.gridy = 0;
        panel.add(txtUsername, gbc);

        JLabel lblPassword = new JLabel("Mật khẩu:");
        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(lblPassword, gbc);

        txtPassword = new JPasswordField();
        gbc.gridx = 1; gbc.gridy = 1;
        panel.add(txtPassword, gbc);

        JLabel lblRole = new JLabel("Vai trò:");
        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(lblRole, gbc);

        JPanel rolePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));

        radioAdmin = new JRadioButton("admin");
        radioStaff = new JRadioButton("staff");
        radioCustomer = new JRadioButton("customer");
        radioCustomer.setSelected(true); // mặc định là customer

        roleGroup = new ButtonGroup();
        roleGroup.add(radioAdmin);
        roleGroup.add(radioStaff);
        roleGroup.add(radioCustomer);

        rolePanel.add(radioAdmin);
        rolePanel.add(radioStaff);
        rolePanel.add(radioCustomer);

        gbc.gridx = 1; gbc.gridy = 2;
        panel.add(rolePanel, gbc);

        btnRegister = new JButton("Đăng ký");
        gbc.gridx = 0; gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(btnRegister, gbc);

        add(panel);
    }

    private void addEvents() {
        btnRegister.addActionListener(e -> {
            String username = getUsername();
            String password = getPassword();
            String role = getRole();

            if (username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Vui lòng nhập tên đăng nhập và mật khẩu!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                return;
            }

            User user = new User();
            user.setUsername(username);
            user.setPassword(password);
            user.setRole(role);

            UserDAO dao = new UserDAO();
            if (dao.addUser(user)) {
                JOptionPane.showMessageDialog(this, "Đăng ký thành công!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                this.dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Tên đăng nhập đã tồn tại hoặc lỗi hệ thống!", "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    public String getUsername() {
        return txtUsername.getText().trim();
    }

    public String getPassword() {
        return new String(txtPassword.getPassword());
    }

    public String getRole() {
        if (radioAdmin.isSelected()) return "admin";
        if (radioStaff.isSelected()) return "staff";
        return "customer";
    }

    public JButton getBtnRegister() {
        return btnRegister;
    }
}
