package dashboard;

import do_an.DBConnection;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.labels.StandardPieSectionLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;

import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.Random;

public class DashboardFrame extends JFrame {

    private JPanel leftPanel, rightPanel, centerPanel;
    private JButton[] chartButtons;
    private JButton[] filterButtons;
    private JButton exitButton;

    private final String[] chartNames = {
            "Tỷ lệ đơn hàng theo trạng thái",
            "Tỷ lệ sản phẩm theo danh mục",
            "Rating trung bình của seller",
            "Tổng số đơn hàng theo ngày",
            "Số đơn hàng theo khách hàng",
            "Số seller theo khoảng rating",
            "Số sản phẩm theo danh mục",
            "Số lượng đơn hàng theo tháng"
    };

    private final Color[] chartButtonColors = {
            new Color(255, 99, 132),
            new Color(54, 162, 235),
            new Color(255, 206, 86),
            new Color(75, 192, 192),
            new Color(153, 102, 255),
            new Color(255, 159, 64),
            new Color(199, 199, 199),
            new Color(83, 102, 255)
    };

    private final String[] filterNames = {"Năm", "Tháng", "Khu vực", "Quản lý", "Tất cả"};
    private final Color[] filterButtonColors = {
            new Color(100, 149, 237),
            new Color(60, 179, 113),
            new Color(218, 112, 214),
            new Color(255, 165, 0),
            new Color(70, 130, 180)
    };
    //
    JComboBox<String> comboNam = new JComboBox<>(new String[] {"2022", "2023", "2024"});
    JComboBox<String> comboThang = new JComboBox<>(new String[] {"Tháng 1", "Tháng 2", "Tháng 3"});
    JComboBox<String> comboKhuVuc = new JComboBox<>(new String[] {"Khu vực 1", "Khu vực 2"});
    JComboBox<String> comboQuanLy = new JComboBox<>(new String[] {"Quản lý A", "Quản lý B"});
    JComboBox<String> comboTatCa = new JComboBox<>(new String[] {"Tất cả"});
//
    private Connection conn;

    // List chứa các ChartPanel để dễ thao tác highlight
    private ArrayList<ChartPanel> chartPanels;

    // Lưu trạng thái filter hiện tại
    private String currentFilter = "Tất cả";

    public DashboardFrame() {
        setTitle("Dashboard Sales");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Mở toàn màn hình
        setExtendedState(JFrame.MAXIMIZED_BOTH);

        setLayout(new BorderLayout());

        conn = DBConnection.getConnection();
        if (conn == null) {
            JOptionPane.showMessageDialog(this, "Không thể kết nối DB.");
            System.exit(1);
        }

        initLeftPanel();
        initRightPanel();
        initCenterPanel();

        add(leftPanel, BorderLayout.WEST);
        add(rightPanel, BorderLayout.EAST);
        add(centerPanel, BorderLayout.CENTER);

        // Nút thoát ở dưới cùng bên trái
        JPanel bottomLeftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        exitButton = new JButton("Thoát");
        exitButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        exitButton.setBackground(Color.RED);
        exitButton.setForeground(Color.WHITE);
        exitButton.setFocusPainted(false);
        exitButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        exitButton.addActionListener(e -> System.exit(0));
        bottomLeftPanel.add(exitButton);
        add(bottomLeftPanel, BorderLayout.SOUTH);

        setVisible(true);

        // Mặc định highlight biểu đồ đầu tiên
        highlightChart(0);
    }

    private void initLeftPanel() {
        leftPanel = new JPanel();
        leftPanel.setLayout(new GridLayout(chartNames.length, 1, 5, 5));
        leftPanel.setPreferredSize(new Dimension(250, getHeight()));
        leftPanel.setBackground(Color.DARK_GRAY);

        chartButtons = new JButton[chartNames.length];
        for (int i = 0; i < chartNames.length; i++) {
            JButton btn = new JButton(chartNames[i]);
            btn.setBackground(chartButtonColors[i]);
            btn.setForeground(Color.WHITE);
            btn.setFocusPainted(false);
            btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
            btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

            final int index = i;
            btn.addActionListener(e -> highlightChart(index));

            btn.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    btn.setBackground(btn.getBackground().darker());
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    btn.setBackground(chartButtonColors[index]);
                }
            });

            chartButtons[i] = btn;
            leftPanel.add(btn);
        }
    }
//
    private void initRightPanel() {
        rightPanel = new JPanel();
        rightPanel.setLayout(new GridLayout(filterNames.length * 2, 1, 5, 5)); // tăng dòng để chứa combo box
        rightPanel.setPreferredSize(new Dimension(140, getHeight()));
        rightPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        filterButtons = new JButton[filterNames.length];
        JComboBox<String>[] combos = new JComboBox[] {
            comboNam, comboThang, comboKhuVuc, comboQuanLy, comboTatCa
        };

        for (int i = 0; i < filterNames.length; i++) {
            JButton btn = new JButton(filterNames[i]);
            btn.setBackground(filterButtonColors[i]);
            btn.setForeground(Color.WHITE);
            btn.setFocusPainted(false);
            btn.setFont(new Font("Segoe UI", Font.PLAIN, 13));
            btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

            final int index = i;
            btn.addActionListener(e -> {
                // Ẩn hết combo box trước
                for (JComboBox<String> combo : combos) {
                    combo.setVisible(false);
                }
                // Hiện combo box tương ứng với nút filter
                combos[index].setVisible(true);
                currentFilter = filterNames[index];
                // Bạn có thể gọi applyFilterToCharts(currentFilter); khi chọn combo box hoặc khi nhấn nút confirm
            });

            btn.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    btn.setBackground(btn.getBackground().darker());
                }
                @Override
                public void mouseExited(MouseEvent e) {
                    btn.setBackground(filterButtonColors[index]);
                }
            });

            filterButtons[i] = btn;
            rightPanel.add(btn);

            // Thêm combo box ẩn phía dưới mỗi nút
            JComboBox<String> combo = combos[i];
            combo.setVisible(false);
            combo.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            combo.addActionListener(ev -> {
                // Khi chọn combo, áp dụng filter (ví dụ in ra thông báo hoặc cập nhật chart)
                String selected = (String) combo.getSelectedItem();
                JOptionPane.showMessageDialog(this,
                        "Nút  '" + filterNames[index] + "' được chọn: " + selected);
                // Áp dụng filter cho biểu đồ
                applyFilterToCharts(filterNames[index]);
            });
            rightPanel.add(combo);
        }
    }

    private void initCenterPanel() {
        centerPanel = new JPanel();
        // Sắp xếp biểu đồ thành lưới 2 cột 4 hàng
        centerPanel.setLayout(new GridLayout(4, 2, 10, 10));
        centerPanel.setBackground(Color.WHITE);
        centerPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        chartPanels = new ArrayList<>();

        // Tạo tất cả biểu đồ rồi thêm vào centerPanel
        for (int i = 0; i < chartNames.length; i++) {
            ChartPanel cp = createChartPanelByIndex(i, currentFilter);
            cp.setBorder(new LineBorder(Color.GRAY, 2)); // Viền mặc định
            chartPanels.add(cp);
            centerPanel.add(cp);
        }
    }

    // Hàm highlight viền cho biểu đồ được chọn, và reset các biểu đồ khác
    private void highlightChart(int index) {
        for (int i = 0; i < chartPanels.size(); i++) {
            if (i == index) {
                chartPanels.get(i).setBorder(new LineBorder(Color.YELLOW, 4));
            } else {
                chartPanels.get(i).setBorder(new LineBorder(Color.GRAY, 2));
            }
        }
    }

    // Cập nhật biểu đồ với filter đã chọn
    private void applyFilterToCharts(String filter) {
        centerPanel.removeAll();
        chartPanels.clear();

        // Tạo lại các biểu đồ dựa trên filter
        for (int i = 0; i < chartNames.length; i++) {
            ChartPanel cp = createChartPanelByIndex(i, filter);
            cp.setBorder(new LineBorder(Color.GRAY, 2));
            chartPanels.add(cp);
            centerPanel.add(cp);
        }

        centerPanel.revalidate();
        centerPanel.repaint();

        // Giữ highlight biểu đồ đầu tiên sau khi refresh
        highlightChart(0);
    }

    private ChartPanel createChartPanelByIndex(int index, String filter) {
        // Nếu filter là "Tất cả" thì dùng dữ liệu thật, ngược lại dùng dữ liệu giả
        if ("Tất cả".equals(filter)) {
            return createRealChartByIndex(index);
        } else {
            return createFakeChartByIndex(index, filter);
        }
    }

    private ChartPanel createRealChartByIndex(int index) {
        switch (index) {
            case 0:
                return createPieChart(
                        "Tỷ lệ đơn hàng theo trạng thái",
                        "SELECT STATUS, COUNT(*) AS total_orders FROM orders GROUP BY STATUS");
            case 1:
                return createPieChart(
                        "Tỷ lệ sản phẩm theo danh mục",
                        "SELECT category, COUNT(*) AS total_products FROM products GROUP BY category");
            case 2:
                return createBarChart(
                        "Rating trung bình của seller",
                        "SELECT seller_id, AVG(rating) AS avg_rating FROM sellers GROUP BY seller_id ORDER BY seller_id",
                        "Seller ID", "Rating");
            case 3:
                return createBarChart(
                        "Tổng số đơn hàng theo ngày",
                        "SELECT order_date, COUNT(order_id) AS daily_orders FROM orders GROUP BY order_date ORDER BY order_date",
                        "Ngày", "Số đơn hàng");
            case 4:
                return createBarChart(
                        "Số đơn hàng theo khách hàng",
                        "SELECT customer_id, COUNT(order_id) AS total_orders FROM orders GROUP BY customer_id ORDER BY total_orders DESC LIMIT 10",
                        "Customer ID", "Số đơn hàng");
            case 5:
                return createPieChart(
                        "Số seller theo khoảng rating",
                        "SELECT CASE " +
                                "WHEN rating >= 0 AND rating < 1 THEN '0-1' " +
                                "WHEN rating >= 1 AND rating < 2 THEN '1-2' " +
                                "WHEN rating >= 2 AND rating < 3 THEN '2-3' " +
                                "WHEN rating >= 3 AND rating < 4 THEN '3-4' " +
                                "ELSE '4-5' END AS rating_range, COUNT(seller_id) AS total_sellers " +
                                "FROM sellers GROUP BY rating_range ORDER BY rating_range");
            case 6:
                return createBarChart(
                        "Số sản phẩm theo danh mục",
                        "SELECT category, COUNT(product_id) AS total_products FROM products GROUP BY category ORDER BY total_products DESC",
                        "Danh mục",
                        "Số sản phẩm");
            case 7:
                return createBarChart(
                        "Số lượng đơn hàng theo tháng",
                        "SELECT MONTH(order_date) AS month, COUNT(order_id) AS total_orders FROM orders GROUP BY month ORDER BY month",
                        "Tháng",
                        "Số lượng đơn hàng");
            default:
                return new ChartPanel(null);
        }
    }

    private ChartPanel createFakeChartByIndex(int index, String filter) {
        Random rand = new Random(filter.hashCode() + index);

        switch (index) {
            case 0:
                // Pie chart đơn hàng trạng thái
                DefaultPieDataset pieDataset = new DefaultPieDataset();
                pieDataset.setValue("Pending", rand.nextInt(100));
                pieDataset.setValue("Confirmed", rand.nextInt(100));
                pieDataset.setValue("Delivered", rand.nextInt(100));
                pieDataset.setValue("Canceled", rand.nextInt(100));
                return createPieChartWithDataset("Đơn hàng theo trạng thái (" + filter + ")", pieDataset);

            case 1:
                // Pie chart sản phẩm theo danh mục
                DefaultPieDataset pieDataset2 = new DefaultPieDataset();
                pieDataset2.setValue("Điện tử", rand.nextInt(150));
                pieDataset2.setValue("Thời trang", rand.nextInt(150));
                pieDataset2.setValue("Gia dụng", rand.nextInt(150));
                pieDataset2.setValue("Sách", rand.nextInt(150));
                return createPieChartWithDataset("Sản phẩm theo danh mục (" + filter + ")", pieDataset2);

            case 2:
                // Bar chart rating seller
                DefaultCategoryDataset barDataset = new DefaultCategoryDataset();
                for (int i = 1; i <= 5; i++) {
                    barDataset.addValue(1 + rand.nextDouble() * 4, "Rating", "Seller " + i);
                }
                return createBarChartWithDataset("Rating trung bình seller (" + filter + ")", barDataset, "Seller", "Rating");

            case 3:
                // Bar chart đơn hàng theo ngày
                DefaultCategoryDataset barDataset2 = new DefaultCategoryDataset();
                for (int d = 1; d <= 7; d++) {
                    barDataset2.addValue(rand.nextInt(100), "Orders", "Ngày " + d);
                }
                return createBarChartWithDataset("Đơn hàng theo ngày (" + filter + ")", barDataset2, "Ngày", "Số đơn hàng");

            case 4:
                // Bar chart đơn hàng theo khách hàng
                DefaultCategoryDataset barDataset3 = new DefaultCategoryDataset();
                for (int c = 1; c <= 5; c++) {
                    barDataset3.addValue(rand.nextInt(100), "Orders", "KH " + c);
                }
                return createBarChartWithDataset("Đơn hàng theo khách hàng (" + filter + ")", barDataset3, "Khách hàng", "Số đơn hàng");

            case 5:
                // Pie chart seller theo rating range
                DefaultPieDataset pieDataset3 = new DefaultPieDataset();
                pieDataset3.setValue("0-1", rand.nextInt(20));
                pieDataset3.setValue("1-2", rand.nextInt(30));
                pieDataset3.setValue("2-3", rand.nextInt(40));
                pieDataset3.setValue("3-4", rand.nextInt(50));
                pieDataset3.setValue("4-5", rand.nextInt(60));
                return createPieChartWithDataset("Seller theo khoảng rating (" + filter + ")", pieDataset3);

            case 6:
                // Bar chart sản phẩm theo danh mục
                DefaultCategoryDataset barDataset4 = new DefaultCategoryDataset();
                barDataset4.addValue(rand.nextInt(100), "Sản phẩm", "Điện tử");
                barDataset4.addValue(rand.nextInt(100), "Sản phẩm", "Thời trang");
                barDataset4.addValue(rand.nextInt(100), "Sản phẩm", "Gia dụng");
                barDataset4.addValue(rand.nextInt(100), "Sản phẩm", "Sách");
                return createBarChartWithDataset("Sản phẩm theo danh mục (" + filter + ")", barDataset4, "Danh mục", "Số lượng");

            case 7:
                // Bar chart đơn hàng theo tháng
                DefaultCategoryDataset barDataset5 = new DefaultCategoryDataset();
                for (int m = 1; m <= 12; m++) {
                    barDataset5.addValue(rand.nextInt(200), "Đơn hàng", "Tháng " + m);
                }
                return createBarChartWithDataset("Đơn hàng theo tháng (" + filter + ")", barDataset5, "Tháng", "Số đơn hàng");

            default:
                return new ChartPanel(null);
        }
    }

    // Tạo biểu đồ Pie dựa trên câu truy vấn SQL
    private ChartPanel createPieChart(String title, String sql) {
        DefaultPieDataset dataset = new DefaultPieDataset();
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                String key = rs.getString(1);
                int value = rs.getInt(2);
                dataset.setValue(key, value);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return createPieChartWithDataset(title, dataset);
    }

    private ChartPanel createPieChartWithDataset(String title, DefaultPieDataset dataset) {
        JFreeChart chart = ChartFactory.createPieChart(title, dataset, true, true, false);
        PiePlot plot = (PiePlot) chart.getPlot();
        plot.setLabelGenerator(new StandardPieSectionLabelGenerator("{0}: {1} ({2})"));
        ChartPanel chartPanel = new ChartPanel(chart);
        return chartPanel;
    }

    // Tạo biểu đồ Bar dựa trên câu truy vấn SQL
    private ChartPanel createBarChart(String title, String sql, String categoryAxisLabel, String valueAxisLabel) {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                String category = rs.getString(1);
                Number value = (Number) rs.getObject(2);
                dataset.addValue(value, "Value", category);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return createBarChartWithDataset(title, dataset, categoryAxisLabel, valueAxisLabel);
    }

    private ChartPanel createBarChartWithDataset(String title, DefaultCategoryDataset dataset,
                                                String categoryAxisLabel, String valueAxisLabel) {
        JFreeChart chart = ChartFactory.createBarChart(title, categoryAxisLabel, valueAxisLabel, dataset);
        CategoryPlot plot = chart.getCategoryPlot();
        BarRenderer renderer = (BarRenderer) plot.getRenderer();
        renderer.setSeriesPaint(0, new Color(79, 129, 189));
        ChartPanel chartPanel = new ChartPanel(chart);
        return chartPanel;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new DashboardFrame());
    }
}
