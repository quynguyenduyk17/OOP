package do_an.model;

public class Product {
    private String productId;
    private String productName;
    private double price;
    private String category;
    private int stockQuantity;
    private String sellerId;

    // Constructor đầy đủ 6 tham số
    public Product(String productId, String productName, double price, String category, int stockQuantity, String sellerId) {
        this.productId = productId;
        this.productName = productName;
        this.price = price;
        this.category = category;
        this.stockQuantity = stockQuantity;
        this.sellerId = sellerId;
    }

    // Constructor không có sellerId (nếu cần)
    public Product(String productId, String productName, double price, String category, int stockQuantity) {
        this(productId, productName, price, category, stockQuantity, null);
    }

    // Constructor chỉ với id, tên, loại, số lượng (để phù hợp với AdminDashboard cũ)
    public Product(String productId, String productName, String category, int stockQuantity) {
        this(productId, productName, 0.0, category, stockQuantity, null);
    }

    
    
    //
    // Thêm thuộc tính imagePath:
    private String imagePath;

    // Thêm constructor 5 tham số:
    public Product(String productId, String productName, String category, int stockQuantity, String imagePath) {
        this.productId = productId;
        this.productName = productName;
        this.category = category;
        this.stockQuantity = stockQuantity;
        this.imagePath = imagePath;
    }

    
    
    // Thêm getter/setter
    public String getImagePath() {
        return imagePath;
    }
    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    // Getter và Setter
    public String getProductId() {
        return productId;
    }
    public void setProductId(String productId) {
        this.productId = productId;
    }
    public String getProductName() {
        return productName;
    }
    public void setProductName(String productName) {
        this.productName = productName;
    }
    public double getPrice() {
        return price;
    }
    public void setPrice(double price) {
        this.price = price;
    }
    public String getCategory() {
        return category;
    }
    public void setCategory(String category) {
        this.category = category;
    }
    public int getStockQuantity() {
        return stockQuantity;
    }
    public void setStockQuantity(int stockQuantity) {
        this.stockQuantity = stockQuantity;
    }
    public String getSellerId() {
        return sellerId;
    }
    public void setSellerId(String sellerId) {
        this.sellerId = sellerId;
    }
//
 // Copy constructor
    public Product(Product other) {
        this.productId = other.productId;
        this.productName = other.productName;
        this.price = other.price;
        this.category = other.category;
        this.stockQuantity = other.stockQuantity;
        this.sellerId = other.sellerId;
        this.imagePath = other.imagePath;
    }


}
