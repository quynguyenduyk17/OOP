package dashboard;

import javax.swing.SwingUtilities;

public class DashboardMain {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            DashboardFrame frame = new DashboardFrame();
            frame.setVisible(true);
        });
    }
}
