package do_an.ui;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;

public class QRCodeDialog extends JDialog {
    private JPanel mainPanel;
    private Timer colorTimer;
    private float hue = 0f;

    public QRCodeDialog(JFrame parent) {
        super(parent, "💳 Quét mã QR để thanh toán", true);
        setSize(700, 750); // Tăng size phù hợp ảnh 600x600 + padding + nút
        setLocationRelativeTo(parent);
        setUndecorated(true);

        initUI();
        startColorEffect();
    }

    private void initUI() {
        mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(20, 20, 40));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        try {
            ImageIcon icon = new ImageIcon(getClass().getResource("/do_an/resources/maQR.jpg"));
            Image image = icon.getImage().getScaledInstance(600, 600, Image.SCALE_SMOOTH);
            JLabel imageLabel = new JLabel(new ImageIcon(image));
            imageLabel.setHorizontalAlignment(JLabel.CENTER);
            mainPanel.add(imageLabel, BorderLayout.CENTER);
        } catch (Exception e) {
            JLabel error = new JLabel("❌ Không tìm thấy ảnh QR");
            error.setForeground(Color.RED);
            error.setFont(new Font("Segoe UI", Font.BOLD, 18));
            error.setHorizontalAlignment(JLabel.CENTER);
            mainPanel.add(error, BorderLayout.CENTER);
        }

        JButton closeButton = new JButton("Đóng");
        closeButton.setFont(new Font("Segoe UI", Font.BOLD, 16));
        closeButton.setBackground(new Color(100, 20, 150));
        closeButton.setForeground(Color.WHITE);
        closeButton.setFocusPainted(false);
        closeButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        closeButton.setPreferredSize(new Dimension(120, 40));
        closeButton.addActionListener(e -> dispose());

        JPanel btnPanel = new JPanel();
        btnPanel.setBackground(mainPanel.getBackground());
        btnPanel.add(closeButton);
        mainPanel.add(btnPanel, BorderLayout.SOUTH);

        add(mainPanel);
    }

    private void startColorEffect() {
        colorTimer = new Timer(100, e -> {
            hue += 0.01f;
            if (hue > 1f) hue = 0f;

            Color borderColor = Color.getHSBColor(hue, 1f, 1f);
            Border glowingBorder = BorderFactory.createLineBorder(borderColor, 5, true);
            mainPanel.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createEmptyBorder(15, 15, 15, 15),
                    glowingBorder
            ));
            mainPanel.repaint();
        });
        colorTimer.start();

        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                colorTimer.stop();
            }

            @Override
            public void windowClosed(java.awt.event.WindowEvent e) {
                colorTimer.stop();
            }
        });
    }

    public static void showDialog(JFrame parent) {
        QRCodeDialog dialog = new QRCodeDialog(parent);
        dialog.setVisible(true);
    }
}
