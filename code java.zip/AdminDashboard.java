package do_an.ui;

import do_an.dao.ProductDAO;
import do_an.model.Product;

import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class AdminDashboard extends JFrame {
    private final ProductDAO productDAO;
    private JTextField txtSearch, txtId, txtName, txtCategory, txtStock;
    private JTable tableProducts;
    private DefaultTableModel model;

    // Màu sắc và hiệu ứng
    private final Color backgroundMain = new Color(18, 18, 25);
    private final Color panelTopColor = new Color(25, 25, 35);
    private final Color textCyan = new Color(0, 255, 255);
    private final Color textFieldBg = new Color(18, 18, 25);
    private final Color textFieldFg = new Color(0, 255, 255);
    private final Color textFieldBorder = new Color(0, 180, 255);
    private final Color buttonBg = new Color(0, 150, 255);
    private final Color buttonFg = Color.WHITE;
    private final Color tableEvenRow = new Color(10, 25, 50);
    private final Color tableOddRow = new Color(18, 35, 70);
    private final Color tableText = new Color(180, 255, 255);
    private final Color tableSelectedBg = new Color(0, 128, 255);
    private final Color tableHeaderBg = new Color(0, 200, 255);
    private final Color tableHeaderFg = Color.BLACK;

    private float gridHue = 0f;

    public AdminDashboard() {
        setTitle("Admin Dashboard - Quản lý sản phẩm");
        setSize(950, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        getContentPane().setBackground(backgroundMain);
        setLayout(new BorderLayout());

        productDAO = new ProductDAO();

        // Panel tìm kiếm
        JPanel panelSearch = new JPanel(new BorderLayout(10, 10));
        panelSearch.setBackground(panelTopColor);
        panelSearch.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel lblSearch = new JLabel("🔍 Tìm kiếm sản phẩm:");
        lblSearch.setForeground(textCyan);

        txtSearch = new JTextField();
        txtSearch.setBackground(textFieldBg);
        txtSearch.setForeground(textFieldFg);
        txtSearch.setCaretColor(textFieldFg);
        txtSearch.setBorder(new LineBorder(textFieldBorder));

        JButton btnSearch = new JButton("Tìm");
        btnSearch.setBackground(buttonBg);
        btnSearch.setForeground(buttonFg);

        panelSearch.add(lblSearch, BorderLayout.WEST);
        panelSearch.add(txtSearch, BorderLayout.CENTER);
        panelSearch.add(btnSearch, BorderLayout.EAST);
        add(panelSearch, BorderLayout.NORTH);

        // Bảng sản phẩm
        model = new DefaultTableModel(new String[]{"Mã SP", "Tên sản phẩm", "Loại", "Số lượng"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tableProducts = new JTable(model);
        tableProducts.setFillsViewportHeight(true);
        tableProducts.setGridColor(Color.CYAN);
        tableProducts.setRowHeight(28);
        tableProducts.setFont(new Font("SansSerif", Font.PLAIN, 13));
        tableProducts.setForeground(tableText);
        tableProducts.setSelectionBackground(tableSelectedBg);
        tableProducts.setSelectionForeground(Color.WHITE);
        tableProducts.setBackground(backgroundMain);

        JTableHeader header = tableProducts.getTableHeader();
        header.setBackground(tableHeaderBg);
        header.setForeground(tableHeaderFg);
        header.setFont(new Font("SansSerif", Font.BOLD, 14));

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                setHorizontalAlignment(SwingConstants.CENTER);
                setForeground(tableText);
                if (isSelected) {
                    setBackground(tableSelectedBg);
                    setForeground(Color.WHITE);
                } else {
                    setBackground(row % 2 == 0 ? tableEvenRow : tableOddRow);
                }
                return this;
            }
        };

        for (int i = 0; i < tableProducts.getColumnCount(); i++) {
            tableProducts.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }

        JScrollPane scrollPane = new JScrollPane(tableProducts);
        scrollPane.setBorder(BorderFactory.createLineBorder(textCyan));
        add(scrollPane, BorderLayout.CENTER);

        // Form nhập liệu
        JPanel panelForm = new JPanel(new GridLayout(5, 2, 8, 8));
        panelForm.setBackground(backgroundMain);
        panelForm.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(textCyan), "Thông tin sản phẩm", 0, 0, null, textCyan));

        txtId = createTextField();
        txtName = createTextField();
        txtCategory = createTextField();
        txtStock = createTextField();

        panelForm.add(createLabel("Mã sản phẩm:"));
        panelForm.add(txtId);

        panelForm.add(createLabel("Tên sản phẩm:"));
        panelForm.add(txtName);

        panelForm.add(createLabel("Loại:"));
        panelForm.add(txtCategory);

        panelForm.add(createLabel("Số lượng:"));
        panelForm.add(txtStock);

        // Các nút chức năng
        JButton btnAdd = createButton("Thêm");
        JButton btnUpdate = createButton("Sửa");
        JButton btnDelete = createButton("Xóa");
        JButton btnStats = createButton("Thống kê");
        JButton btnReview = createButton("Xem đánh giá");
        JButton btnSellers = createButton("Sellers");
        JButton btnCustomers = createButton("Khách hàng"); // nút mới thêm

        JPanel panelButtons = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        panelButtons.setBackground(backgroundMain);
        panelButtons.add(btnAdd);
        panelButtons.add(btnUpdate);
        panelButtons.add(btnDelete);
        panelButtons.add(btnStats);
        panelButtons.add(btnReview);
        panelButtons.add(btnSellers);
        panelButtons.add(btnCustomers);  // thêm nút Khách hàng vào panel

        JPanel panelSouth = new JPanel(new BorderLayout());
        panelSouth.setBackground(backgroundMain);
        panelSouth.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panelSouth.add(panelForm, BorderLayout.CENTER);
        panelSouth.add(panelButtons, BorderLayout.SOUTH);
        add(panelSouth, BorderLayout.SOUTH);

        // Load dữ liệu
        loadAllProducts();

        // Gán sự kiện
        btnSearch.addActionListener(e -> searchProducts());
        txtSearch.addActionListener(e -> searchProducts());
        btnAdd.addActionListener(e -> addProduct());
        btnUpdate.addActionListener(e -> updateProduct());
        btnDelete.addActionListener(e -> deleteProduct());
        btnStats.addActionListener(e -> {
            dashboard.DashboardFrame statsFrame = new dashboard.DashboardFrame();
            statsFrame.setVisible(true);
        });

        btnReview.addActionListener(e -> {
            int row = tableProducts.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(this, "Chọn sản phẩm để xem đánh giá.", "Thông báo", JOptionPane.WARNING_MESSAGE);
                return;
            }
            String productId = model.getValueAt(row, 0).toString();
            ReviewFrame reviewFrame = new ReviewFrame(productId);
            reviewFrame.setVisible(true);
        });

        btnSellers.addActionListener(e -> {
            SellersTableView sellersFrame = new SellersTableView();
            sellersFrame.setVisible(true);
        });

        btnCustomers.addActionListener(e -> {
            CustomersTableView customersFrame = new CustomersTableView();
            customersFrame.setVisible(true);
        });

        tableProducts.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int row = tableProducts.getSelectedRow();
                if (row >= 0) {
                    txtId.setText(model.getValueAt(row, 0).toString());
                    txtName.setText(model.getValueAt(row, 1).toString());
                    txtCategory.setText(model.getValueAt(row, 2).toString());
                    txtStock.setText(model.getValueAt(row, 3).toString());
                    txtId.setEditable(false);
                }
            }
        });

        // Hiệu ứng lưới màu động
        new Timer(100, e -> {
            gridHue += 0.01f;
            if (gridHue > 1f) gridHue = 0f;
            Color dynamicGridColor = Color.getHSBColor(gridHue, 0.7f, 1f);
            tableProducts.setGridColor(dynamicGridColor);
            tableProducts.repaint();
        }).start();
    }

    private void loadAllProducts() {
        model.setRowCount(0);
        for (Product p : productDAO.getAllProducts()) {
            model.addRow(new Object[]{p.getProductId(), p.getProductName(), p.getCategory(), p.getStockQuantity()});
        }
        txtId.setEditable(true);
        clearForm();
    }

    private void searchProducts() {
        String keyword = txtSearch.getText().trim();
        model.setRowCount(0);
        List<Product> list = keyword.isEmpty() ? productDAO.getAllProducts() : productDAO.searchProducts(keyword);
        for (Product p : list) {
            model.addRow(new Object[]{p.getProductId(), p.getProductName(), p.getCategory(), p.getStockQuantity()});
        }
    }

    private void addProduct() {
        String id = txtId.getText().trim();
        String name = txtName.getText().trim();
        String category = txtCategory.getText().trim();
        String stockStr = txtStock.getText().trim();
        if (id.isEmpty() || name.isEmpty() || category.isEmpty() || stockStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập đủ thông tin.", "Lỗi", JOptionPane.ERROR_MESSAGE);
            return;
        }
        try {
            int stock = Integer.parseInt(stockStr);
            Product p = new Product(id, name, category, stock);
            if (productDAO.addProduct(p)) {
                JOptionPane.showMessageDialog(this, "Thêm sản phẩm thành công.");
                loadAllProducts();
            } else {
                JOptionPane.showMessageDialog(this, "Mã đã tồn tại.", "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Số lượng phải là số nguyên.", "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateProduct() {
        int row = tableProducts.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Chọn sản phẩm để sửa.", "Thông báo", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String id = txtId.getText().trim();
        String name = txtName.getText().trim();
        String category = txtCategory.getText().trim();
        String stockStr = txtStock.getText().trim();
        if (id.isEmpty() || name.isEmpty() || category.isEmpty() || stockStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập đủ thông tin.", "Lỗi", JOptionPane.ERROR_MESSAGE);
            return;
        }
        try {
            int stock = Integer.parseInt(stockStr);
            Product p = new Product(id, name, category, stock);
            if (productDAO.updateProduct(p)) {
                JOptionPane.showMessageDialog(this, "Cập nhật sản phẩm thành công.");
                loadAllProducts();
            } else {
                JOptionPane.showMessageDialog(this, "Cập nhật thất bại.", "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Số lượng phải là số nguyên.", "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteProduct() {
        int row = tableProducts.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Chọn sản phẩm để xóa.", "Thông báo", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String id = model.getValueAt(row, 0).toString();
        int confirm = JOptionPane.showConfirmDialog(this, "Bạn chắc chắn muốn xóa sản phẩm này?", "Xác nhận", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (productDAO.deleteProduct(id)) {
                JOptionPane.showMessageDialog(this, "Xóa sản phẩm thành công.");
                loadAllProducts();
            } else {
                JOptionPane.showMessageDialog(this, "Xóa thất bại.", "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private JTextField createTextField() {
        JTextField tf = new JTextField();
        tf.setBackground(textFieldBg);
        tf.setForeground(textFieldFg);
        tf.setCaretColor(textFieldFg);
        tf.setBorder(new LineBorder(textFieldBorder));
        return tf;
    }

    private JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(textCyan);
        return label;
    }

    private JButton createButton(String text) {
        JButton btn = new JButton(text);
        btn.setBackground(buttonBg);
        btn.setForeground(buttonFg);
        btn.setFocusPainted(false);
        return btn;
    }

    private void clearForm() {
        txtId.setText("");
        txtName.setText("");
        txtCategory.setText("");
        txtStock.setText("");
        txtId.setEditable(true);
    }

    // Bạn nhớ tạo class CustomersTableView riêng nha
}
