package do_an.ui;

import do_an.dao.ProductDAO;
import do_an.model.Product;
import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;
import do_an.dao.ProductDAO;
import javax.swing.ImageIcon;
import java.awt.image.BufferedImage;
import java.awt.Image;

public class CustomerDashboard extends JFrame {
    private List<Product> productList;
    private JTable tblProducts;
    private DefaultTableModel model;
    private JTextField txtSearch;
    private JComboBox<String> cboCategoryFilter;
    private JComboBox<String> cboSort;

    private Map<String, Product> cart = new HashMap<>();
    private CartDialog cartDialog;

    public CustomerDashboard() {
        initData();
        initComponents();
        loadProducts(productList);
    }
    
    private void initData() {
        ProductDAO productDAO = new ProductDAO();
        productList = productDAO.getAllProducts();
    }
    
    private void initComponents() {
        setTitle("Customer Dashboard - Marketplace");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout(15, 15));

        getContentPane().setBackground(new Color(18, 18, 25));

        JLabel lblTitle = new JLabel("Danh sách sản phẩm");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 36));
        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitle.setForeground(new Color(0, 255, 255));
        lblTitle.setBorder(BorderFactory.createEmptyBorder(30, 10, 30, 10));
        add(lblTitle, BorderLayout.NORTH);

        JPanel topFilterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 10));
        topFilterPanel.setBackground(new Color(25, 25, 35));

        topFilterPanel.add(createLabelWithColor("Lọc danh mục:", new Color(0, 255, 255)));
        cboCategoryFilter = new JComboBox<>();
        cboCategoryFilter.addItem("Tất cả");
        getAllCategories().forEach(cboCategoryFilter::addItem);
        styleComboBox(cboCategoryFilter);
        topFilterPanel.add(cboCategoryFilter);

        topFilterPanel.add(createLabelWithColor("Sắp xếp:", new Color(0, 255, 255)));
        cboSort = new JComboBox<>(new String[]{"Tên A-Z", "Tên Z-A", "Số lượng tăng", "Số lượng giảm"});
        styleComboBox(cboSort);
        topFilterPanel.add(cboSort);

        topFilterPanel.add(createLabelWithColor("Tìm kiếm:", new Color(0, 255, 255)));
        txtSearch = new JTextField(20);
        styleTextField(txtSearch);
        topFilterPanel.add(txtSearch);

        JButton btnSearch = createStyledButton("Tìm kiếm");
        topFilterPanel.add(btnSearch);

        JButton btnRefresh = createStyledButton("Làm mới");
        topFilterPanel.add(btnRefresh);

        model = new DefaultTableModel(new Object[]{"Ảnh", "Mã sản phẩm", "Tên sản phẩm", "Danh mục", "Số lượng tồn", "Thêm vào giỏ"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 5;
            }

            @Override
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex == 0) return ImageIcon.class;
                if (columnIndex == 5) return JButton.class;
                if (columnIndex == 4) return Integer.class;
                return String.class;
            }
        };

        tblProducts = new JTable(model) {
            @Override
            public Component prepareRenderer(TableCellRenderer renderer, int row, int column) {
                Component c = super.prepareRenderer(renderer, row, column);
                if (!isRowSelected(row)) {
                    c.setBackground(row % 2 == 0 ? new Color(10, 25, 50) : new Color(18, 35, 70));
                    c.setForeground(new Color(180, 255, 255));
                } else {
                    c.setBackground(new Color(0, 128, 255));
                    c.setForeground(Color.WHITE);
                }
                return c;
            }
        };

        tblProducts.setRowHeight(60);
        tblProducts.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 16));
        tblProducts.getTableHeader().setBackground(new Color(0, 200, 255));
        tblProducts.getTableHeader().setForeground(Color.BLACK);
        tblProducts.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        tblProducts.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tblProducts.setShowGrid(false);
        tblProducts.setIntercellSpacing(new Dimension(0, 0));
        tblProducts.getColumn("Thêm vào giỏ").setCellRenderer(new ButtonRenderer());
        tblProducts.getColumn("Thêm vào giỏ").setCellEditor(new ButtonEditor(new JCheckBox()));
        tblProducts.getColumn("Số lượng tồn").setCellRenderer(new StockQuantityRenderer());

        JScrollPane scrollPane = new JScrollPane(tblProducts);
        scrollPane.setPreferredSize(new Dimension(900, 550));
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(0, 255, 255)));

        JPanel centerPanel = new JPanel(new BorderLayout(0, 10));
        centerPanel.setBackground(new Color(18, 18, 25));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(0, 20, 20, 20));
        centerPanel.add(topFilterPanel, BorderLayout.NORTH);
        centerPanel.add(scrollPane, BorderLayout.CENTER);

        add(centerPanel, BorderLayout.CENTER);

        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
        rightPanel.setBorder(BorderFactory.createEmptyBorder(100, 20, 100, 20));
        rightPanel.setBackground(new Color(15, 15, 30));

        JButton btnViewCart = createStyledButton("Giỏ hàng");
        JButton btnCheckout = createStyledButton("Thanh toán");
        JButton btnBackHome = createStyledButton("Trang chủ");

        rightPanel.add(Box.createVerticalGlue());
        rightPanel.add(btnViewCart);
        rightPanel.add(Box.createRigidArea(new Dimension(0, 30)));
        rightPanel.add(btnCheckout);
        rightPanel.add(Box.createRigidArea(new Dimension(0, 30)));
        rightPanel.add(btnBackHome);
        rightPanel.add(Box.createVerticalGlue());

        add(rightPanel, BorderLayout.EAST);

        btnSearch.addActionListener(e -> applyFilters());
        txtSearch.addActionListener(e -> applyFilters());
        btnRefresh.addActionListener(e -> {
            txtSearch.setText("");
            cboCategoryFilter.setSelectedIndex(0);
            cboSort.setSelectedIndex(0);
            loadProducts(productList);
        });

        cboCategoryFilter.addActionListener(e -> applyFilters());
        cboSort.addActionListener(e -> applyFilters());

//        btnViewCart.addActionListener(e -> {
//            if (cartDialog == null) cartDialog = new CartDialog(this, cart);
//            cartDialog.setVisible(true);
//        });
//
        btnViewCart.addActionListener(e -> {
            CartView cartView = new CartView(this, cart); // `this` là parent
            cartView.setVisible(true);
        });

//        
        btnCheckout.addActionListener(e -> checkout());

        btnBackHome.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Quay về trang chủ");
        });

        tblProducts.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int row = tblProducts.getSelectedRow();
                    if (row != -1) {
                        String productId = tblProducts.getValueAt(row, 1).toString();
                        Product p = findProductById(productId);
                        if (p != null) {
                            JOptionPane.showMessageDialog(CustomerDashboard.this,
                                    "Chi tiết sản phẩm:\n" +
                                            "Mã: " + p.getProductId() + "\n" +
                                            "Tên: " + p.getProductName() + "\n" +
                                            "Danh mục: " + p.getCategory() + "\n" +
                                            "Số lượng tồn: " + p.getStockQuantity());
                        }
                    }
                }
            }
        });

        pack();
        setLocationRelativeTo(null);
    }

    private JLabel createLabelWithColor(String text, Color color) {
        JLabel lbl = new JLabel(text);
        lbl.setForeground(color);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 16));
        return lbl;
    }

    private void styleComboBox(JComboBox<String> comboBox) {
        comboBox.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        comboBox.setBackground(new Color(18, 18, 25));
        comboBox.setForeground(new Color(0, 255, 255));
        comboBox.setFocusable(false);
        comboBox.setBorder(BorderFactory.createLineBorder(new Color(0, 180, 255)));
    }

    private void styleTextField(JTextField textField) {
textField.setFont(new Font("Segoe UI", Font.PLAIN, 16));
textField.setBackground(new Color(18, 18, 25));
textField.setForeground(new Color(0, 255, 255));
textField.setCaretColor(new Color(0, 255, 255));
textField.setBorder(BorderFactory.createLineBorder(new Color(0, 180, 255)));
}
private JButton createStyledButton(String text) {
    JButton btn = new JButton(text);
    btn.setFont(new Font("Segoe UI", Font.BOLD, 18));
    btn.setBackground(new Color(0, 150, 255));
    btn.setForeground(Color.WHITE);
    btn.setFocusPainted(false);
    btn.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
    btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
    return btn;
}

private List<String> getAllCategories() {
    return productList.stream()
            .map(Product::getCategory)
            .distinct()
            .collect(Collectors.toList());
}

//private void loadProducts(List<Product> products) {
//    model.setRowCount(0);
//    for (Product p : products) {
//        ImageIcon icon = null;
//        try {
//            icon = new ImageIcon(new ImageIcon(getClass().getResource(p.getImagePath())).getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH));
//        } catch (Exception e) {
//            // Nếu không tìm thấy ảnh, hiển thị icon mặc định
//          
//        }
//        model.addRow(new Object[]{icon, p.getProductId(), p.getProductName(), p.getCategory(), p.getStockQuantity(), "Thêm"});
//    }
//}

private void loadProducts(List<Product> products) {
    model.setRowCount(0);
    for (Product p : products) {
        ImageIcon icon = null;
        try {
            Image img = new ImageIcon(getClass().getResource(p.getImagePath())).getImage();
            icon = new ImageIcon(img.getScaledInstance(60, 60, Image.SCALE_SMOOTH));
        } catch (Exception e) {
//            icon = new ImageIcon(new BufferedImage(60, 60, BufferedImage.TYPE_INT_ARGB)); // fallback
        	icon = new ImageIcon((Image) new BufferedImage(60, 60, BufferedImage.TYPE_INT_ARGB));

        }

        JButton btnAdd = new JButton("Thêm");
        btnAdd.addActionListener(e -> {
            if (p.getStockQuantity() <= 0) {
                JOptionPane.showMessageDialog(this, "Sản phẩm đã hết hàng!", "Thông báo", JOptionPane.WARNING_MESSAGE);
                return;
            }
            cart.put(p.getProductId(), p);
            JOptionPane.showMessageDialog(this, "Đã thêm vào giỏ hàng!");
        });

        model.addRow(new Object[]{icon, p.getProductId(), p.getProductName(), p.getCategory(), p.getStockQuantity(), btnAdd});
    }
}

private void applyFilters() {
    String keyword = txtSearch.getText().trim().toLowerCase();
    String category = (String) cboCategoryFilter.getSelectedItem();
    String sortBy = (String) cboSort.getSelectedItem();

    List<Product> filtered = productList.stream()
            .filter(p -> (category.equals("Tất cả") || p.getCategory().equals(category)))
            .filter(p -> p.getProductName().toLowerCase().contains(keyword))
            .collect(Collectors.toList());

    switch (sortBy) {
        case "Tên A-Z":
            filtered.sort(Comparator.comparing(Product::getProductName));
            break;
        case "Tên Z-A":
            filtered.sort(Comparator.comparing(Product::getProductName).reversed());
            break;
        case "Số lượng tăng":
            filtered.sort(Comparator.comparingInt(Product::getStockQuantity));
            break;
        case "Số lượng giảm":
            filtered.sort(Comparator.comparingInt(Product::getStockQuantity).reversed());
            break;
    }

    loadProducts(filtered);
}

private Product findProductById(String id) {
    return productList.stream().filter(p -> p.getProductId().equals(id)).findFirst().orElse(null);
}

private void checkout() {
    if (cart.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Giỏ hàng đang trống.");
        return;
    }
    // Kiểm tra tồn kho
    for (Product p : cart.values()) {
        Product orig = findProductById(p.getProductId());
        if (orig == null || orig.getStockQuantity() < 1) {
            JOptionPane.showMessageDialog(this, "Sản phẩm " + p.getProductName() + " không đủ tồn kho.");
            return;
        }
    }
    // Giảm tồn kho
    for (Product p : cart.values()) {
        Product orig = findProductById(p.getProductId());
        orig.setStockQuantity(orig.getStockQuantity() - 1);
    }
    cart.clear();
    if (cartDialog != null) cartDialog.refreshCart();

    JOptionPane.showMessageDialog(this, "Thanh toán thành công!");
    loadProducts(productList);
}

// Button Renderer cho cột "Thêm vào giỏ"
class ButtonRenderer extends JButton implements TableCellRenderer {
    public ButtonRenderer() {
        setOpaque(true);
        setBackground(new Color(0, 150, 255));
        setForeground(Color.WHITE);
        setFont(new Font("Segoe UI", Font.BOLD, 14));
    }

    public Component getTableCellRendererComponent(JTable table, Object value,
                                                   boolean isSelected, boolean hasFocus,
                                                   int row, int column) {
        setText((value == null) ? "Thêm" : value.toString());
        return this;
    }
}

// Button Editor cho cột "Thêm vào giỏ"
class ButtonEditor extends DefaultCellEditor {
    protected JButton button;
    private String label;
    private boolean clicked;
    private int row;

    public ButtonEditor(JCheckBox checkBox) {
        super(checkBox);
        button = new JButton();
        button.setOpaque(true);
        button.setBackground(new Color(0, 150, 255));
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.addActionListener(e -> fireEditingStopped());
    }

    public Component getTableCellEditorComponent(JTable table, Object value,
                                                 boolean isSelected, int row, int column) {
        label = (value == null) ? "Thêm" : value.toString();
        button.setText(label);
        clicked = true;
        this.row = row;
        return button;
    }

    public Object getCellEditorValue() {
        if (clicked) {
            String productId = tblProducts.getValueAt(row, 1).toString();
            Product p = findProductById(productId);
            if (p.getStockQuantity() == 0) {
                JOptionPane.showMessageDialog(CustomerDashboard.this, "Sản phẩm đã hết hàng!");
            } else if (cart.containsKey(productId)) {
                JOptionPane.showMessageDialog(CustomerDashboard.this, "Sản phẩm đã có trong giỏ hàng!");
            } else {
                cart.put(productId, new Product(p.getProductId(), p.getProductName(), p.getCategory(), 1, p.getImagePath()));
                JOptionPane.showMessageDialog(CustomerDashboard.this, "Đã thêm sản phẩm vào giỏ hàng!");
            }
        }
        clicked = false;
        return label;
    }

    public boolean stopCellEditing() {
        clicked = false;
        return super.stopCellEditing();
    }
}

// Renderer cho cột Số lượng tồn để đổi màu khi hết hàng
class StockQuantityRenderer extends DefaultTableCellRenderer {
    @Override
    public void setValue(Object value) {
        super.setValue(value);
        if (value instanceof Integer) {
            int quantity = (Integer) value;
            if (quantity == 0) {
                setForeground(Color.RED);
            } else {
                setForeground(new Color(180, 255, 255));
            }
        }
    }
}

// Dialog hiển thị giỏ hàng
class CartDialog extends JDialog {
    private Map<String, Product> cart;
    private DefaultTableModel cartModel;
    private JTable cartTable;

    public CartDialog(Frame owner, Map<String, Product> cart) {
        super(owner, "Giỏ hàng của bạn", true);
        this.cart = cart;
        initUI();
        refreshCart();
        setSize(600, 400);
        setLocationRelativeTo(owner);
    }

    private void initUI() {
        setLayout(new BorderLayout(10, 10));
        getContentPane().setBackground(new Color(18, 18, 25));

        cartModel = new DefaultTableModel(new Object[]{"Mã sản phẩm", "Tên sản phẩm", "Số lượng"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 2; // chỉ cho sửa số lượng
            }

            @Override
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex == 2) return Integer.class;
                return String.class;
            }
        };

        cartTable = new JTable(cartModel);
        cartTable.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        cartTable.setRowHeight(30);
        JScrollPane scrollPane = new JScrollPane(cartTable);
        add(scrollPane, BorderLayout.CENTER);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnPanel.setBackground(new Color(18, 18, 25));

        JButton btnRemove = new JButton("Xóa sản phẩm");
        JButton btnUpdate = new JButton("Cập nhật số lượng");
        JButton btnClose = new JButton("Đóng");

        btnRemove.setBackground(new Color(255, 70, 70));
        btnRemove.setForeground(Color.WHITE);
        btnUpdate.setBackground(new Color(0, 150, 255));
        btnUpdate.setForeground(Color.WHITE);
        btnClose.setBackground(new Color(100, 100, 100));
        btnClose.setForeground(Color.WHITE);

        btnPanel.add(btnRemove);
        btnPanel.add(btnUpdate);
        btnPanel.add(btnClose);

        add(btnPanel, BorderLayout.SOUTH);

        btnRemove.addActionListener(e -> {
            int row = cartTable.getSelectedRow();
            if (row >= 0) {
                String productId = cartTable.getValueAt(row, 0).toString();
                cart.remove(productId);
                refreshCart();
            } else {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn sản phẩm để xóa.");
            }
        });

        btnUpdate.addActionListener(e -> {
            for (int i = 0; i < cartModel.getRowCount(); i++) {
                String productId = cartModel.getValueAt(i, 0).toString();
                Object val = cartModel.getValueAt(i, 2);
                int qty;
                try {
                    qty = Integer.parseInt(val.toString());
                    if (qty < 1) throw new NumberFormatException();
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "Số lượng phải là số nguyên dương.");
                    return;
                }
                Product p = findProductById(productId);
                if (qty > p.getStockQuantity()) {
                    JOptionPane.showMessageDialog(this, "Số lượng sản phẩm " + p.getProductName() + " vượt quá tồn kho.");
                    return;
                }
                cart.put(productId, new Product(p.getProductId(), p.getProductName(), p.getCategory(), qty, p.getImagePath()));
            }
            JOptionPane.showMessageDialog(this, "Cập nhật giỏ hàng thành công!");
            refreshCart();
        });

        btnClose.addActionListener(e -> setVisible(false));
    }

    public void refreshCart() {
        cartModel.setRowCount(0);
        for (Product p : cart.values()) {
            cartModel.addRow(new Object[]{p.getProductId(), p.getProductName(), p.getStockQuantity()});
        }
    }
}

public static void main(String[] args) {
    // Đảm bảo giao diện Swing được chạy trên Event Dispatch Thread
    javax.swing.SwingUtilities.invokeLater(() -> {
        new CustomerDashboard().setVisible(true);
    });
}
}

