package do_an.model;

public class Review {
    private String productId;
    private String user;
    private int rating;
    private String comment;

    public Review(String productId, String user, int rating, String comment) {
        this.productId = productId;
        this.user = user;
        this.rating = rating;
        this.comment = comment;
    }

    public String getProductId() { return productId; }
    public String getUser() { return user; }
    public int getRating() { return rating; }
    public String getComment() { return comment; }
}
