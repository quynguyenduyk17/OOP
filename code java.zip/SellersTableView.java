package do_an.ui;

import do_an.DBConnection;

import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;

public class SellersTableView extends JFrame {
    private JTable table;
    private DefaultTableModel tableModel;

    // Màu sắc đồng bộ với AdminDashboard
    private final Color backgroundMain = new Color(18, 18, 25);
    private final Color tableEvenRow = new Color(10, 25, 50);
    private final Color tableOddRow = new Color(18, 35, 70);
    private final Color tableText = new Color(180, 255, 255);
    private final Color tableSelectedBg = new Color(0, 128, 255);
    private final Color tableHeaderBg = new Color(0, 200, 255);
    private final Color tableHeaderFg = Color.BLACK;

    private float gridHue = 0f;

    // Panel chứa các nút chức năng
    private JPanel buttonPanel;
    private JButton btnAdd, btnEdit, btnDelete, btnRefresh, btnExportCSV;

    public SellersTableView() {
        setTitle("Danh sách Sellers");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Panel chính
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(backgroundMain);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        setContentPane(mainPanel);

        // Tạo table và model
        tableModel = new DefaultTableModel();
        table = new JTable(tableModel);
        table.setFillsViewportHeight(true);
        table.setRowHeight(28);
        table.setFont(new Font("SansSerif", Font.PLAIN, 13));
        table.setForeground(tableText);
        table.setSelectionBackground(tableSelectedBg);
        table.setSelectionForeground(Color.WHITE);
        table.setBackground(backgroundMain);
        table.setGridColor(Color.CYAN);

        // Renderer căn giữa, đổi màu xen kẽ
        DefaultTableCellRenderer cellRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                setHorizontalAlignment(SwingConstants.CENTER);
                setForeground(tableText);
                if (isSelected) {
                    setBackground(tableSelectedBg);
                    setForeground(Color.WHITE);
                } else {
                    setBackground(row % 2 == 0 ? tableEvenRow : tableOddRow);
                }
                return this;
            }
        };
        table.setDefaultRenderer(Object.class, cellRenderer);

        // Header bảng
        JTableHeader header = table.getTableHeader();
        header.setBackground(tableHeaderBg);
        header.setForeground(tableHeaderFg);
        header.setFont(new Font("SansSerif", Font.BOLD, 14));
        ((DefaultTableCellRenderer) header.getDefaultRenderer()).setHorizontalAlignment(SwingConstants.CENTER);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(tableHeaderBg));
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        // Panel nút
        buttonPanel = new JPanel();
        buttonPanel.setBackground(backgroundMain);
        buttonPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));
        mainPanel.add(buttonPanel, BorderLayout.NORTH);

        // Tạo các nút chức năng
        btnAdd = new JButton("Thêm");
        btnEdit = new JButton("Sửa");
        btnDelete = new JButton("Xóa");
        btnRefresh = new JButton("Làm mới");
        btnExportCSV = new JButton("Xuất CSV");

        // Đặt font và màu cho nút
        JButton[] buttons = {btnAdd, btnEdit, btnDelete, btnRefresh, btnExportCSV};
        for (JButton b : buttons) {
            b.setFocusPainted(false);
            b.setBackground(new Color(0, 150, 255));
            b.setForeground(Color.WHITE);
            b.setFont(new Font("SansSerif", Font.BOLD, 14));
            b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            buttonPanel.add(b);
        }

        // Thêm sự kiện cho nút
        btnAdd.addActionListener(e -> openAddDialog());
        btnEdit.addActionListener(e -> openEditDialog());
        btnDelete.addActionListener(e -> deleteSellers());
        btnRefresh.addActionListener(e -> loadSellersData());
        btnExportCSV.addActionListener(e -> exportToCSV());

        // Load dữ liệu ban đầu
        loadSellersData();

        // Timer thay đổi màu grid theo hue chuyển động
        new Timer(100, e -> {
            gridHue += 0.01f;
            if (gridHue > 1f) gridHue = 0f;
            Color dynamicGridColor = Color.getHSBColor(gridHue, 0.7f, 1f);
            table.setGridColor(dynamicGridColor);
            table.repaint();
        }).start();

        setVisible(true);
    }

    private void loadSellersData() {
        String sql = "SELECT * FROM sellers";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();

            tableModel.setRowCount(0);
            tableModel.setColumnCount(0);

            for (int i = 1; i <= columnCount; i++) {
                tableModel.addColumn(metaData.getColumnLabel(i));
            }

            while (rs.next()) {
                Object[] rowData = new Object[columnCount];
                for (int i = 0; i < columnCount; i++) {
                    rowData[i] = rs.getObject(i + 1);
                }
                tableModel.addRow(rowData);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi kết nối hoặc truy vấn dữ liệu!", "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void openAddDialog() {
        SellerFormDialog dialog = new SellerFormDialog(this, "Thêm Người Bán", null);
        dialog.setVisible(true);
        if (dialog.isSucceeded()) {
            loadSellersData();
        }
    }

    private void openEditDialog() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn một người bán để sửa.", "Thông báo", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int modelRow = table.convertRowIndexToModel(selectedRow);

        // Lấy dữ liệu dòng đã chọn
        int colCount = tableModel.getColumnCount();
        Object[] rowData = new Object[colCount];
        for (int i = 0; i < colCount; i++) {
            rowData[i] = tableModel.getValueAt(modelRow, i);
        }
        SellerFormDialog dialog = new SellerFormDialog(this, "Sửa Người Bán", rowData);
        dialog.setVisible(true);
        if (dialog.isSucceeded()) {
            loadSellersData();
        }
    }

    private void deleteSellers() {
        int[] selectedRows = table.getSelectedRows();
        if (selectedRows.length == 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn người bán để xoá.", "Thông báo", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this,
                "Bạn có chắc chắn muốn xoá " + selectedRows.length + " người bán?",
                "Xác nhận xoá", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);
            String sql = "DELETE FROM sellers WHERE id = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                for (int row : selectedRows) {
                    int modelRow = table.convertRowIndexToModel(row);
                    String id = tableModel.getValueAt(modelRow, 0).toString();
                    ps.setString(1, id);
                    ps.addBatch();
                }
                ps.executeBatch();
                conn.commit();
                JOptionPane.showMessageDialog(this, "Xoá người bán thành công.");
                loadSellersData();
            } catch (SQLException ex) {
                conn.rollback();
                throw ex;
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi xoá người bán: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void exportToCSV() {
        // Tạo dialog lưu file tùy chỉnh
        JDialog dialog = new JDialog(this, "Lưu file CSV", true);
        dialog.setSize(450, 180);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());

        // Panel gradient background
        JPanel mainPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                Color colorStart = new Color(0, 150, 255);
                Color colorEnd = new Color(0, 80, 160);
                GradientPaint gp = new GradientPaint(0, 0, colorStart, 0, getHeight(), colorEnd);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        mainPanel.setLayout(new GridBagLayout());
        dialog.add(mainPanel, BorderLayout.CENTER);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lbl = new JLabel("Chọn thư mục và đặt tên file (.csv):");
        lbl.setForeground(Color.WHITE);
        lbl.setFont(new Font("SansSerif", Font.BOLD, 16));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        mainPanel.add(lbl, gbc);

        JTextField txtPath = new JTextField();
        txtPath.setFont(new Font("SansSerif", Font.PLAIN, 14));
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        mainPanel.add(txtPath, gbc);

        JButton btnBrowse = new JButton("Chọn...");
        btnBrowse.setBackground(new Color(0, 180, 255));
        btnBrowse.setForeground(Color.WHITE);
        btnBrowse.setFocusPainted(false);
        btnBrowse.setFont(new Font("SansSerif", Font.BOLD, 14));
        btnBrowse.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        gbc.gridx = 1;
        mainPanel.add(btnBrowse, gbc);

        JPanel btnPanel = new JPanel();
        btnPanel.setBackground(new Color(0, 80, 160));
        JButton btnSave = new JButton("Lưu");
        JButton btnCancel = new JButton("Huỷ");

        // Style nút
        for (JButton b : new JButton[]{btnSave, btnCancel}) {
            b.setBackground(new Color(0, 150, 255));
            b.setForeground(Color.WHITE);
            b.setFocusPainted(false);
            b.setFont(new Font("SansSerif", Font.BOLD, 14));
            b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            b.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        }

        btnPanel.add(btnSave);
        btnPanel.add(btnCancel);
        dialog.add(btnPanel, BorderLayout.SOUTH);

        btnBrowse.addActionListener(e -> {
            JFileChooser chooser = new JFileChooser();
            chooser.setDialogTitle("Chọn thư mục lưu file");
            chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            int ret = chooser.showOpenDialog(dialog);
            if (ret == JFileChooser.APPROVE_OPTION) {
                txtPath.setText(chooser.getSelectedFile().getAbsolutePath() + "/data.csv");
            }
        });

        btnSave.addActionListener(e -> {
            String path = txtPath.getText().trim();
            if (path.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Vui lòng nhập hoặc chọn đường dẫn lưu file!", "Thông báo", JOptionPane.WARNING_MESSAGE);
                return;
            }
            if (!path.toLowerCase().endsWith(".csv")) {
                path += ".csv";
            }
            try (FileWriter csvWriter = new FileWriter(path)) {
                // Ghi header
                for (int i = 0; i < tableModel.getColumnCount(); i++) {
                    csvWriter.append(tableModel.getColumnName(i));
                    if (i != tableModel.getColumnCount() - 1) csvWriter.append(",");
                }
                csvWriter.append("\n");
                // Ghi dữ liệu từng dòng
                for (int i = 0; i < tableModel.getRowCount(); i++) {
                    for (int j = 0; j < tableModel.getColumnCount(); j++) {
                        Object val = tableModel.getValueAt(i, j);
                        csvWriter.append(val == null ? "" : val.toString());
                        if (j != tableModel.getColumnCount() - 1) csvWriter.append(",");
                    }
                    csvWriter.append("\n");
                }
                JOptionPane.showMessageDialog(dialog, "Xuất file CSV thành công!");
                dialog.dispose();
            } catch (IOException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(dialog, "Lỗi xuất file CSV: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnCancel.addActionListener(e -> dialog.dispose());

        dialog.setVisible(true);
    }

//    
    // Dialog thêm/sửa người bán
    private static class SellerFormDialog extends JDialog {
        private JTextField txtId, txtName, txtEmail, txtPhone;
        private boolean succeeded;

        public SellerFormDialog(Frame parent, String title, Object[] data) {
            super(parent, title, true);
            setSize(400, 320);
            setLocationRelativeTo(parent);
            setLayout(new BorderLayout());
            setResizable(false);

            // Font đẹp cho label và input
            Font fontLabel = new Font("Segoe UI", Font.BOLD, 14);
            Font fontInput = new Font("Segoe UI", Font.PLAIN, 14);
            Font fontBtn = new Font("Segoe UI", Font.BOLD, 14);

            // Panel form với màu nền sáng, padding
            JPanel formPanel = new JPanel(new GridLayout(4, 2, 15, 15));
            formPanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 20, 30));
            formPanel.setBackground(new Color(245, 245, 245)); // màu nền sáng nhẹ

            JLabel lblId = new JLabel("ID:");
            lblId.setFont(fontLabel);
            lblId.setForeground(new Color(50, 50, 50));
            txtId = new JTextField();
            txtId.setFont(fontInput);

            JLabel lblName = new JLabel("Tên:");
            lblName.setFont(fontLabel);
            lblName.setForeground(new Color(50, 50, 50));
            txtName = new JTextField();
            txtName.setFont(fontInput);

            JLabel lblEmail = new JLabel("Email:");
            lblEmail.setFont(fontLabel);
            lblEmail.setForeground(new Color(50, 50, 50));
            txtEmail = new JTextField();
            txtEmail.setFont(fontInput);

            JLabel lblPhone = new JLabel("Số điện thoại:");
            lblPhone.setFont(fontLabel);
            lblPhone.setForeground(new Color(50, 50, 50));
            txtPhone = new JTextField();
            txtPhone.setFont(fontInput);

            formPanel.add(lblId);
            formPanel.add(txtId);
            formPanel.add(lblName);
            formPanel.add(txtName);
            formPanel.add(lblEmail);
            formPanel.add(txtEmail);
            formPanel.add(lblPhone);
            formPanel.add(txtPhone);

            add(formPanel, BorderLayout.CENTER);

            // Panel nút với màu nền trung tính
            JPanel btnPanel = new JPanel();
            btnPanel.setBackground(new Color(245, 245, 245));
            btnPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 20, 10));

            JButton btnSave = new JButton("Lưu");
            btnSave.setFont(fontBtn);
            btnSave.setBackground(new Color(76, 175, 80)); // xanh lá tươi
            btnSave.setForeground(Color.WHITE);
            btnSave.setFocusPainted(false);
            btnSave.setCursor(new Cursor(Cursor.HAND_CURSOR));

            JButton btnCancel = new JButton("Huỷ");
            btnCancel.setFont(fontBtn);
            btnCancel.setBackground(new Color(244, 67, 54)); // đỏ tươi
            btnCancel.setForeground(Color.WHITE);
            btnCancel.setFocusPainted(false);
            btnCancel.setCursor(new Cursor(Cursor.HAND_CURSOR));

            // Hiệu ứng hover cho nút Lưu
            btnSave.addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseEntered(java.awt.event.MouseEvent evt) {
                    btnSave.setBackground(new Color(56, 142, 60));
                }
                public void mouseExited(java.awt.event.MouseEvent evt) {
                    btnSave.setBackground(new Color(76, 175, 80));
                }
            });

            // Hiệu ứng hover cho nút Huỷ
            btnCancel.addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseEntered(java.awt.event.MouseEvent evt) {
                    btnCancel.setBackground(new Color(211, 47, 47));
                }
                public void mouseExited(java.awt.event.MouseEvent evt) {
                    btnCancel.setBackground(new Color(244, 67, 54));
                }
            });

            btnPanel.add(btnSave);
            btnPanel.add(btnCancel);
            add(btnPanel, BorderLayout.SOUTH);

            // Nếu sửa thì điền dữ liệu vào form
            if (data != null) {
                txtId.setText(data[0].toString());
                txtId.setEditable(false); // không được sửa ID
                txtName.setText(data[1] == null ? "" : data[1].toString());
                txtEmail.setText(data[2] == null ? "" : data[2].toString());
                txtPhone.setText(data[3] == null ? "" : data[3].toString());
            }

            btnSave.addActionListener(e -> {
                if (txtId.getText().trim().isEmpty() || txtName.getText().trim().isEmpty()) {
                    JOptionPane.showMessageDialog(SellerFormDialog.this,
                            "ID và Tên không được để trống!", "Thông báo", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                if (data == null) { // thêm mới
                    if (insertSeller(txtId.getText().trim(), txtName.getText().trim(),
                            txtEmail.getText().trim(), txtPhone.getText().trim())) {
                        succeeded = true;
                        dispose();
                    }
                } else { // sửa
                    if (updateSeller(txtId.getText().trim(), txtName.getText().trim(),
                            txtEmail.getText().trim(), txtPhone.getText().trim())) {
                        succeeded = true;
                        dispose();
                    }
                }
            });

            btnCancel.addActionListener(e -> {
                succeeded = false;
                dispose();
            });
        }


        public boolean isSucceeded() {
            return succeeded;
        }

        private boolean insertSeller(String id, String name, String email, String phone) {
            String sql = "INSERT INTO sellers (id, name, email, phone) VALUES (?, ?, ?, ?)";
            try (Connection conn = DBConnection.getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, id);
                ps.setString(2, name);
                ps.setString(3, email);
                ps.setString(4, phone);
                ps.executeUpdate();
                JOptionPane.showMessageDialog(this, "Thêm người bán thành công.");
                return true;
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Lỗi thêm người bán: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        }

        private boolean updateSeller(String id, String name, String email, String phone) {
            String sql = "UPDATE sellers SET name = ?, email = ?, phone = ? WHERE id = ?";
            try (Connection conn = DBConnection.getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, name);
                ps.setString(2, email);
                ps.setString(3, phone);
                ps.setString(4, id);
                int rowsUpdated = ps.executeUpdate();
                if (rowsUpdated > 0) {
                    JOptionPane.showMessageDialog(this, "Sửa người bán thành công.");
                    return true;
                } else {
                    JOptionPane.showMessageDialog(this, "Không tìm thấy người bán để sửa.", "Lỗi", JOptionPane.ERROR_MESSAGE);
                    return false;
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Lỗi sửa người bán: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        }

//        
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SellersTableView());
    }
}
