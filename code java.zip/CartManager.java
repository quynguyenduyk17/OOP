package do_an.ui;

import java.util.ArrayList;
import java.util.List;

public class CartManager {
    private static CartManager instance;
    private final List<Object[]> cartItems;

    private CartManager() {
        cartItems = new ArrayList<>();
    }

    public static synchronized CartManager getInstance() {
        if (instance == null) {
            instance = new CartManager();
        }
        return instance;
    }

    /**
     * Thêm sản phẩm vào giỏ hàng
     * @param productName Tên sản phẩm
     * @param quantity Số lượng
     * @param price Giá (đơn vị)
     */
    public void addItem(String productName, int quantity, double price) {
        // Kiểm tra sản phẩm đã có trong giỏ chưa, nếu có cộng dồn số lượng
        for (Object[] item : cartItems) {
            if (item[0].equals(productName)) {
                int oldQuantity = (int) item[1];
                item[1] = oldQuantity + quantity;
                // Cập nhật thành tiền
                item[3] = ((int) item[1]) * (double) item[2];
                return;
            }
        }
        // Nếu chưa có, thêm mới
        cartItems.add(new Object[]{productName, quantity, price, quantity * price});
    }

    /**
     * Xóa sản phẩm theo tên
     */
    public void removeItem(String productName) {
        cartItems.removeIf(item -> item[0].equals(productName));
    }

    /**
     * Lấy danh sách sản phẩm trong giỏ hàng
     * Mỗi phần tử là Object[] {Tên sản phẩm, Số lượng, Giá, Thành tiền}
     */
    public List<Object[]> getItems() {
        return new ArrayList<>(cartItems);
    }

    /**
     * Xóa sạch giỏ hàng
     */
    public void clearCart() {
        cartItems.clear();
    }
}
