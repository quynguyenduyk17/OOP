package do_an.ui;

import do_an.dao.ReviewDAO;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class ReviewFrame extends JFrame {
    public ReviewFrame(String productId) {
        setTitle("Đánh giá sản phẩm - " + productId);
        setSize(600, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        ReviewDAO reviewDAO = new ReviewDAO();
        List<String> reviews = reviewDAO.getReviewsByProductId(productId);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(new Color(25, 25, 35));
        panel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));

        for (String review : reviews) {
            JLabel lbl = new JLabel("• " + review);
            lbl.setForeground(Color.CYAN);
            lbl.setFont(new Font("SansSerif", Font.PLAIN, 26));  // tăng kích thước chữ
            lbl.setAlignmentX(Component.LEFT_ALIGNMENT);
            panel.add(lbl);
            panel.add(Box.createVerticalStrut(30));  // tăng khoảng cách giữa các đánh giá
        }

        JScrollPane scrollPane = new JScrollPane(panel);
        scrollPane.setBorder(BorderFactory.createLineBorder(Color.CYAN, 2));

        add(scrollPane);
    }
}
