package do_an.ui;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

public class DiscountCodeDialog extends JDialog {
    private JTextField txtCode;
    private JLabel lblStatus;
    private JButton btnApply;
    private JTable tblCodes;
    private double discountAmount = 0;

    private static final Map<String, Double> FAKE_CODES = new HashMap<>();

    static {
        // Thêm 50 mã FREESHIP
        for (int i = 1; i <= 50; i++) {
            FAKE_CODES.put("FREESHIP" + i, 15000.0);
        }
        // Thêm 50 mã GIAM
        for (int i = 1; i <= 50; i++) {
            FAKE_CODES.put("GIAM" + i, 9000.0 + i * 1000); // GIAM1 = 10000 -> GIAM50 = 59000
        }
    }

    public DiscountCodeDialog(JFrame parent, ActionListener onApplyDiscount) {
        super(parent, "Mã giảm giá", true);
        setSize(600, 360);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout(10, 10));
        getContentPane().setBackground(new Color(30, 30, 60));

        // Tiêu đề
        JLabel lblTitle = new JLabel("Chọn hoặc nhập mã giảm giá:");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitle.setForeground(Color.CYAN);
        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
        add(lblTitle, BorderLayout.NORTH);

        // Bảng mã giảm giá
        String[] columnNames = {"Mã giảm giá", "Số tiền giảm"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
        for (Map.Entry<String, Double> entry : FAKE_CODES.entrySet()) {
            model.addRow(new Object[]{entry.getKey(), String.format("%.0f đ", entry.getValue())});
        }

        tblCodes = new JTable(model) {
            public boolean isCellEditable(int row, int column) {
                return false; // Không cho sửa bảng
            }
        };
        tblCodes.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tblCodes.setRowHeight(24);
        tblCodes.setSelectionBackground(new Color(0, 100, 180));
        tblCodes.setForeground(Color.WHITE);
        tblCodes.setGridColor(Color.CYAN);
        tblCodes.setBackground(new Color(40, 40, 70));

        // Áp dụng renderer có hiệu ứng chuyển động
        tblCodes.setDefaultRenderer(Object.class, new AnimatedTableCellRenderer());

        JScrollPane scrollPane = new JScrollPane(tblCodes);
        scrollPane.setPreferredSize(new Dimension(580, 140));
        add(scrollPane, BorderLayout.CENTER);

        // Sự kiện chọn dòng trong bảng
        tblCodes.getSelectionModel().addListSelectionListener(e -> {
            int selectedRow = tblCodes.getSelectedRow();
            if (selectedRow >= 0) {
                String code = tblCodes.getValueAt(selectedRow, 0).toString();
                txtCode.setText(code);
            }
        });

        // Panel chứa ô nhập và nút áp dụng
        JPanel inputPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        inputPanel.setBackground(new Color(30, 30, 60));

        txtCode = new JTextField(15);
        txtCode.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        txtCode.setHorizontalAlignment(SwingConstants.CENTER);
        txtCode.setBackground(new Color(50, 50, 80));
        txtCode.setForeground(Color.WHITE);
        txtCode.setCaretColor(Color.WHITE);
        txtCode.setBorder(BorderFactory.createLineBorder(Color.CYAN, 2));
        inputPanel.add(txtCode);

        btnApply = new JButton("Áp dụng");
        btnApply.setPreferredSize(new Dimension(120, 35));
        btnApply.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnApply.setBackground(new Color(0, 153, 76));
        btnApply.setForeground(Color.WHITE);
        btnApply.setFocusPainted(false);
        inputPanel.add(btnApply);

        // Panel dưới cùng chứa cả input và label trạng thái
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setBackground(new Color(30, 30, 60));
        bottomPanel.add(inputPanel, BorderLayout.CENTER);

        lblStatus = new JLabel(" ");
        lblStatus.setHorizontalAlignment(SwingConstants.CENTER);
        lblStatus.setForeground(Color.YELLOW);
        lblStatus.setFont(new Font("Segoe UI", Font.ITALIC, 14));
        bottomPanel.add(lblStatus, BorderLayout.SOUTH);

        add(bottomPanel, BorderLayout.SOUTH);

        // Sự kiện khi nhấn nút áp dụng
        btnApply.addActionListener(e -> {
            String code = txtCode.getText().trim().toUpperCase();
            if (FAKE_CODES.containsKey(code)) {
                discountAmount = FAKE_CODES.get(code);
                lblStatus.setText("✅ Áp dụng thành công! Giảm " + String.format("%.0f", discountAmount) + " đ");
                onApplyDiscount.actionPerformed(null);
                dispose();
            } else {
                lblStatus.setText("❌ Mã không hợp lệ!");
            }
        });
    }

    public double getDiscountAmount() {
        return discountAmount;
    }

    // Renderer bảng với hiệu ứng chuyển động ánh sáng lưới
    private static class AnimatedTableCellRenderer extends DefaultTableCellRenderer {
        private int animationStep = 0;
        private final Color baseColor = new Color(40, 40, 70);
        private final Color highlightColor = new Color(0, 180, 255);

        public AnimatedTableCellRenderer() {
            Timer timer = new Timer(120, e -> {
                animationStep = (animationStep + 1) % 100;
                SwingUtilities.invokeLater(() -> {
                    // repaint toàn bảng khi có hiệu ứng
                    // Không thể lấy table trực tiếp, nên dùng cách này cho an toàn
                    // Lớp con gọi repaint() trên component cha
                    // Nếu muốn chính xác hơn, có thể lưu ref bảng nhưng trong context này ổn
                });
            });
            timer.start();
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                                                       boolean isSelected, boolean hasFocus, int row, int column) {
            super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            setForeground(Color.WHITE);
            setFont(new Font("Segoe UI", Font.PLAIN, 14));
            setHorizontalAlignment(CENTER);

            if (isSelected) {
                setBackground(new Color(0, 100, 180));
            } else {
                float alpha = (float) ((Math.sin((row + animationStep * 0.1)) + 1) / 2);
                Color animatedColor = blendColors(baseColor, highlightColor, alpha * 0.2f);
                setBackground(animatedColor);
            }
            return this;
        }

        private Color blendColors(Color c1, Color c2, float ratio) {
            int red = (int) (c1.getRed() * (1 - ratio) + c2.getRed() * ratio);
            int green = (int) (c1.getGreen() * (1 - ratio) + c2.getGreen() * ratio);
            int blue = (int) (c1.getBlue() * (1 - ratio) + c2.getBlue() * ratio);
            return new Color(red, green, blue);
        }
    }
}
