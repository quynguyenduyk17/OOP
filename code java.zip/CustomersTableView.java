package do_an.ui;

import do_an.DBConnection;

import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;

public class CustomersTableView extends JFrame {
    private JTable table;
    private DefaultTableModel tableModel;
    private JTextField txtSearch;
    private float gridHue = 0f;

    // Màu sắc đồng bộ với AdminDashboard và SellersTableView
    private final Color backgroundMain = new Color(18, 18, 25);
    private final Color tableEvenRow = new Color(10, 25, 50);
    private final Color tableOddRow = new Color(18, 35, 70);
    private final Color tableText = new Color(180, 255, 255);
    private final Color tableSelectedBg = new Color(0, 128, 255);
    private final Color tableHeaderBg = new Color(0, 200, 255);
    private final Color tableHeaderFg = Color.BLACK;

    public CustomersTableView() {
        setTitle("Danh sách Customers");
        setSize(900, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Panel chính
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(backgroundMain);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        setContentPane(mainPanel);

        // Phần trên: thanh công cụ với tìm kiếm và nút
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.setBackground(backgroundMain);

        txtSearch = new JTextField(20);
        txtSearch.setFont(new Font("SansSerif", Font.PLAIN, 14));
        txtSearch.setToolTipText("Tìm kiếm theo tên hoặc email...");
        topPanel.add(new JLabel("Tìm kiếm:"));
        topPanel.add(txtSearch);

        JButton btnSearch = new JButton("Tìm");
        JButton btnRefresh = new JButton("Làm mới");
        JButton btnAdd = new JButton("Thêm");
        JButton btnEdit = new JButton("Sửa");
        JButton btnDelete = new JButton("Xóa");
        JButton btnExport = new JButton("Xuất CSV");

        btnSearch.setFocusable(false);
        btnRefresh.setFocusable(false);
        btnAdd.setFocusable(false);
        btnEdit.setFocusable(false);
        btnDelete.setFocusable(false);
        btnExport.setFocusable(false);

        topPanel.add(btnSearch);
        topPanel.add(btnRefresh);
        topPanel.add(btnAdd);
        topPanel.add(btnEdit);
        topPanel.add(btnDelete);
        topPanel.add(btnExport);

        mainPanel.add(topPanel, BorderLayout.NORTH);

        // Bảng dữ liệu
        tableModel = new DefaultTableModel();
        table = new JTable(tableModel);
        table.setFillsViewportHeight(true);
        table.setRowHeight(28);
        table.setFont(new Font("SansSerif", Font.PLAIN, 13));
        table.setForeground(tableText);
        table.setSelectionBackground(tableSelectedBg);
        table.setSelectionForeground(Color.WHITE);
        table.setBackground(backgroundMain);
        table.setGridColor(Color.CYAN);

        // Renderer căn giữa, đổi màu xen kẽ, màu chọn
        DefaultTableCellRenderer cellRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                setHorizontalAlignment(SwingConstants.CENTER);
                setForeground(tableText);
                if (isSelected) {
                    setBackground(tableSelectedBg);
                    setForeground(Color.WHITE);
                } else {
                    setBackground(row % 2 == 0 ? tableEvenRow : tableOddRow);
                }
                return this;
            }
        };
        table.setDefaultRenderer(Object.class, cellRenderer);

        JTableHeader header = table.getTableHeader();
        header.setBackground(tableHeaderBg);
        header.setForeground(tableHeaderFg);
        header.setFont(new Font("SansSerif", Font.BOLD, 14));
        ((DefaultTableCellRenderer) header.getDefaultRenderer()).setHorizontalAlignment(SwingConstants.CENTER);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(tableHeaderBg));
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        // Load dữ liệu ban đầu
        loadCustomersData();

        // Timer thay đổi màu grid theo hue chuyển động
        new Timer(100, e -> {
            gridHue += 0.01f;
            if (gridHue > 1f) gridHue = 0f;
            Color dynamicGridColor = Color.getHSBColor(gridHue, 0.7f, 1f);
            table.setGridColor(dynamicGridColor);
            table.repaint();
        }).start();

        // Action listeners cho các nút
        btnSearch.addActionListener(e -> searchCustomers());
        btnRefresh.addActionListener(e -> loadCustomersData());
        btnAdd.addActionListener(e -> openCustomerForm(null));
        btnEdit.addActionListener(e -> editSelectedCustomer());
        btnDelete.addActionListener(e -> deleteSelectedCustomer());
        btnExport.addActionListener(e -> exportToCSV());

        setVisible(true);
    }

    private void loadCustomersData() {
        String sql = "SELECT * FROM customers";
        loadDataFromQuery(sql);
    }

    private void searchCustomers() {
        String keyword = txtSearch.getText().trim();
        if (keyword.isEmpty()) {
            loadCustomersData();
            return;
        }
        String sql = "SELECT * FROM customers WHERE name LIKE ? OR email LIKE ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            String likeKeyword = "%" + keyword + "%";
            pstmt.setString(1, likeKeyword);
            pstmt.setString(2, likeKeyword);
            try (ResultSet rs = pstmt.executeQuery()) {
                loadDataFromResultSet(rs);
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi tìm kiếm dữ liệu!", "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadDataFromQuery(String sql) {
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            loadDataFromResultSet(rs);
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi tải dữ liệu!", "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadDataFromResultSet(ResultSet rs) throws SQLException {
        ResultSetMetaData metaData = rs.getMetaData();
        int columnCount = metaData.getColumnCount();

        tableModel.setRowCount(0);
        tableModel.setColumnCount(0);

        for (int i = 1; i <= columnCount; i++) {
            tableModel.addColumn(metaData.getColumnLabel(i));
        }

        while (rs.next()) {
            Object[] rowData = new Object[columnCount];
            for (int i = 0; i < columnCount; i++) {
                rowData[i] = rs.getObject(i + 1);
            }
            tableModel.addRow(rowData);
        }
    }

    private void openCustomerForm(Object[] customerData) {
        // Tạo form nhập liệu thêm hoặc sửa khách hàng
        JDialog dialog = new JDialog(this, true);
        dialog.setTitle(customerData == null ? "Thêm khách hàng" : "Sửa khách hàng");
        dialog.setSize(400, 400);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new GridLayout(7, 2, 10, 10));
        dialog.getContentPane().setBackground(backgroundMain);

        JLabel lblId = new JLabel("ID:");
        JTextField txtId = new JTextField();
        txtId.setEnabled(false);
        JLabel lblName = new JLabel("Tên:");
        JTextField txtName = new JTextField();
        JLabel lblEmail = new JLabel("Email:");
        JTextField txtEmail = new JTextField();
        JLabel lblPhone = new JLabel("Số điện thoại:");
        JTextField txtPhone = new JTextField();
        JLabel lblAddress = new JLabel("Địa chỉ:");
        JTextField txtAddress = new JTextField();
        JLabel lblNote = new JLabel("Ghi chú:");
        JTextField txtNote = new JTextField();

        // Set màu cho label và textfield
        for (Component c : new Component[]{lblId, lblName, lblEmail, lblPhone, lblAddress, lblNote}) {
            c.setForeground(tableText);
            c.setFont(new Font("SansSerif", Font.BOLD, 14));
        }
        for (JTextField tf : new JTextField[]{txtId, txtName, txtEmail, txtPhone, txtAddress, txtNote}) {
            tf.setBackground(new Color(30, 30, 30));
            tf.setForeground(tableText);
            tf.setBorder(new LineBorder(tableHeaderBg));
            tf.setFont(new Font("SansSerif", Font.PLAIN, 14));
        }

        dialog.add(lblId);
        dialog.add(txtId);
        dialog.add(lblName);
        dialog.add(txtName);
        dialog.add(lblEmail);
        dialog.add(txtEmail);
        dialog.add(lblPhone);
        dialog.add(txtPhone);
        dialog.add(lblAddress);
        dialog.add(txtAddress);
        dialog.add(lblNote);
        dialog.add(txtNote);

        JButton btnSave = new JButton("Lưu");
        JButton btnCancel = new JButton("Hủy");

        btnSave.setFocusable(false);
        btnCancel.setFocusable(false);

        dialog.add(btnSave);
        dialog.add(btnCancel);

        if (customerData != null) {
            txtId.setText(customerData[0].toString());
            txtName.setText(customerData[1].toString());
            txtEmail.setText(customerData[2].toString());
            txtPhone.setText(customerData[3] == null ? "" : customerData[3].toString());
            txtAddress.setText(customerData[4] == null ? "" : customerData[4].toString());
            txtNote.setText(customerData.length > 5 && customerData[5] != null ? customerData[5].toString() : "");
        }

        btnSave.addActionListener(e -> {
            String name = txtName.getText().trim();
            String email = txtEmail.getText().trim();
            String phone = txtPhone.getText().trim();
            String address = txtAddress.getText().trim();
            String note = txtNote.getText().trim();

            if (name.isEmpty() || email.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Tên và Email không được để trống!", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
                return;
            }

            if (customerData == null) {
                // Thêm mới
                addCustomer(name, email, phone, address, note);
            } else {
                // Cập nhật
                int id = Integer.parseInt(txtId.getText());
                updateCustomer(id, name, email, phone, address, note);
            }

            dialog.dispose();
            loadCustomersData();
        });

        btnCancel.addActionListener(e -> dialog.dispose());

        dialog.setVisible(true);
    }

    private void addCustomer(String name, String email, String phone, String address, String note) {
        String sql = "INSERT INTO customers(name, email, phone, address, note) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, name);
            pstmt.setString(2, email);
            pstmt.setString(3, phone);
            pstmt.setString(4, address);
            pstmt.setString(5, note);
            int result = pstmt.executeUpdate();
            if (result > 0) {
                JOptionPane.showMessageDialog(this, "Thêm khách hàng thành công!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi thêm khách hàng!", "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateCustomer(int id, String name, String email, String phone, String address, String note) {
        String sql = "UPDATE customers SET name=?, email=?, phone=?, address=?, note=? WHERE id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, name);
            pstmt.setString(2, email);
            pstmt.setString(3, phone);
            pstmt.setString(4, address);
            pstmt.setString(5, note);
            pstmt.setInt(6, id);
            int result = pstmt.executeUpdate();
            if (result > 0) {
                JOptionPane.showMessageDialog(this, "Cập nhật khách hàng thành công!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi cập nhật khách hàng!", "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void editSelectedCustomer() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn khách hàng để sửa.", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        int modelRow = table.convertRowIndexToModel(selectedRow);
        Object[] customerData = new Object[tableModel.getColumnCount()];
        for (int i = 0; i < customerData.length; i++) {
            customerData[i] = tableModel.getValueAt(modelRow, i);
        }
        openCustomerForm(customerData);
    }

    private void deleteSelectedCustomer() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn khách hàng để xóa.", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn xóa khách hàng này?", "Xác nhận", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        int modelRow = table.convertRowIndexToModel(selectedRow);
        int id = (int) tableModel.getValueAt(modelRow, 0);
        String sql = "DELETE FROM customers WHERE id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            int result = pstmt.executeUpdate();
            if (result > 0) {
                JOptionPane.showMessageDialog(this, "Xóa khách hàng thành công!");
                loadCustomersData();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi xóa khách hàng!", "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void exportToCSV() {
        // Tạo dialog lưu file tùy chỉnh
        JDialog dialog = new JDialog(this, "Lưu file CSV", true);
        dialog.setSize(450, 180);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());

        // Panel gradient background
        JPanel mainPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                Color colorStart = new Color(0, 150, 255);
                Color colorEnd = new Color(0, 80, 160);
                GradientPaint gp = new GradientPaint(0, 0, colorStart, 0, getHeight(), colorEnd);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        mainPanel.setLayout(new GridBagLayout());
        dialog.add(mainPanel, BorderLayout.CENTER);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lbl = new JLabel("Chọn thư mục và đặt tên file (.csv):");
        lbl.setForeground(Color.WHITE);
        lbl.setFont(new Font("SansSerif", Font.BOLD, 16));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        mainPanel.add(lbl, gbc);

        JTextField txtPath = new JTextField();
        txtPath.setFont(new Font("SansSerif", Font.PLAIN, 14));
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        mainPanel.add(txtPath, gbc);

        JButton btnBrowse = new JButton("Chọn...");
        btnBrowse.setBackground(new Color(0, 180, 255));
        btnBrowse.setForeground(Color.WHITE);
        btnBrowse.setFocusPainted(false);
        btnBrowse.setFont(new Font("SansSerif", Font.BOLD, 14));
        btnBrowse.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        gbc.gridx = 1;
        mainPanel.add(btnBrowse, gbc);

        JPanel btnPanel = new JPanel();
        btnPanel.setBackground(new Color(0, 80, 160));
        JButton btnSave = new JButton("Lưu");
        JButton btnCancel = new JButton("Huỷ");

        // Style nút
        for (JButton b : new JButton[]{btnSave, btnCancel}) {
            b.setBackground(new Color(0, 150, 255));
            b.setForeground(Color.WHITE);
            b.setFocusPainted(false);
            b.setFont(new Font("SansSerif", Font.BOLD, 14));
            b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            b.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        }

        btnPanel.add(btnSave);
        btnPanel.add(btnCancel);
        dialog.add(btnPanel, BorderLayout.SOUTH);

        btnBrowse.addActionListener(e -> {
            JFileChooser chooser = new JFileChooser();
            chooser.setDialogTitle("Chọn thư mục lưu file");
            chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            int ret = chooser.showOpenDialog(dialog);
            if (ret == JFileChooser.APPROVE_OPTION) {
                File selectedDir = chooser.getSelectedFile();
                if (selectedDir.isDirectory()) {
                    txtPath.setText(selectedDir.getAbsolutePath() + "/data.csv");
                } else {
                    JOptionPane.showMessageDialog(dialog, "Vui lòng chọn thư mục, không chọn file!", "Thông báo", JOptionPane.WARNING_MESSAGE);
                }
            }
        });

        btnSave.addActionListener(e -> {
            String path = txtPath.getText().trim();
            if (path.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Vui lòng nhập hoặc chọn đường dẫn lưu file!", "Thông báo", JOptionPane.WARNING_MESSAGE);
                return;
            }
            if (!path.toLowerCase().endsWith(".csv")) {
                path += ".csv";
            }

            File file = new File(path);
            // Nếu file đã tồn tại, hỏi người dùng có muốn ghi đè không
            if (file.exists()) {
                int option = JOptionPane.showConfirmDialog(dialog, "File đã tồn tại. Bạn có muốn ghi đè?", "Xác nhận", JOptionPane.YES_NO_OPTION);
                if (option != JOptionPane.YES_OPTION) {
                    return;
                }
            }

            try (FileWriter csvWriter = new FileWriter(file)) {
                // Ghi header
                for (int i = 0; i < tableModel.getColumnCount(); i++) {
                    csvWriter.append(escapeCSV(tableModel.getColumnName(i)));
                    if (i != tableModel.getColumnCount() - 1) csvWriter.append(",");
                }
                csvWriter.append("\n");

                // Ghi dữ liệu từng dòng
                for (int i = 0; i < tableModel.getRowCount(); i++) {
                    for (int j = 0; j < tableModel.getColumnCount(); j++) {
                        Object val = tableModel.getValueAt(i, j);
                        csvWriter.append(escapeCSV(val == null ? "" : val.toString()));
                        if (j != tableModel.getColumnCount() - 1) csvWriter.append(",");
                    }
                    csvWriter.append("\n");
                }

                JOptionPane.showMessageDialog(dialog, "Xuất file CSV thành công!");
                dialog.dispose();
            } catch (IOException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(dialog, "Lỗi xuất file CSV: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnCancel.addActionListener(e -> dialog.dispose());

        dialog.setVisible(true);
    }

    // Hàm hỗ trợ escape CSV (bọc dữ liệu có dấu phẩy, dấu nháy kép trong dấu nháy kép)
    private String escapeCSV(String data) {
        if (data.contains(",") || data.contains("\"") || data.contains("\n")) {
            data = data.replace("\"", "\"\"");
            return "\"" + data + "\"";
        }
        return data;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CustomersTableView());
    }
}
