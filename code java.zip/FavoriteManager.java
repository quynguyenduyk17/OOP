package do_an.ui;

import java.util.ArrayList;
import java.util.List;

public class FavoriteManager {
    private static final List<String> favoriteProducts = new ArrayList<>();

    public static void addFavorite(String productName) {
        if (!favoriteProducts.contains(productName)) {
            favoriteProducts.add(productName);
        }
    }

    public static void addFavorites(List<String> products) {
        for (String product : products) {
            addFavorite(product);
        }
    }

    public static boolean isFavorite(String productName) {
        return favoriteProducts.contains(productName);
    }

    public static void removeFavorite(String productName) {
        favoriteProducts.remove(productName);
    }

    public static List<String> getFavorites() {
        return new ArrayList<>(favoriteProducts); // Tránh bị chỉnh sửa trực tiếp từ bên ngoài
    }
}
