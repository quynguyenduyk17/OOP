package do_an;

import do_an.ui.CustomerDashboard;

public class MainApp {
    public static void main(String[] args) {
        new CustomerDashboard(); 
    }
}
