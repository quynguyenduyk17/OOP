package do_an.dao;

import java.util.*;

public class ReviewDAO {
    private final Map<String, List<String>> fakeReviews = new HashMap<>();

    public ReviewDAO() {
        for (int i = 3; i <= 32; i++) {
            String productId = String.format("prod%03d", i);
            List<String> reviews = new ArrayList<>();
            reviews.add("👍 Sản phẩm chất lượng, rất hài lòng.");
            reviews.add("⭐ Giao hàng nhanh, đóng gói cẩn thận.");
            reviews.add("❗ Giá hơi cao so với chất lượng.");
            reviews.add("✅ Đúng mô tả, sẽ ủng hộ lần sau.");
            fakeReviews.put(productId, reviews);
        }
    }

    public List<String> getReviewsByProductId(String productId) {
        return fakeReviews.getOrDefault(productId, Collections.singletonList("Chưa có đánh giá."));
    }
}
