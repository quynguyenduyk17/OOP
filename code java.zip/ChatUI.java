package do_an.ui;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Timer;
import java.util.TimerTask;

public class ChatUI extends JFrame {
    private JTextArea chatArea;
    private JTextField inputField;
    private JButton sendButton;

    private float hue = 0f;  // dùng cho hiệu ứng màu chữ động
    private float borderHue = 0f; // dùng cho hiệu ứng viền động
    private float sparkleHue = 0f; // dùng cho hiệu ứng lấp lánh nền

    public ChatUI() {
        setTitle("Giao diện Chat màu mè nền tối");
        setSize(700, 700);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        // Panel chính có background tối với hiệu ứng lấp lánh động
        JPanel mainPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();

                // Background đen xám gradient nhẹ
                Color dark1 = new Color(15, 15, 25);
                Color dark2 = new Color(35, 35, 50);
                GradientPaint gp = new GradientPaint(0, 0, dark1, getWidth(), getHeight(), dark2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());

                // Vẽ các chấm lấp lánh màu sắc chuyển động
                for (int i = 0; i < 50; i++) {
                    float angle = (sparkleHue + i * 0.1f) % 1f;
                    int x = (int) (Math.sin(angle * 2 * Math.PI) * getWidth() / 2 + getWidth() / 2);
                    int y = (int) (Math.cos(angle * 2 * Math.PI) * getHeight() / 2 + getHeight() / 2);
                    int size = (int) (Math.abs(Math.sin(angle * 8 * Math.PI)) * 4 + 1);
                    g2d.setColor(Color.getHSBColor(angle, 0.7f, 1f));
                    g2d.fillOval(x, y, size, size);
                }

                g2d.dispose();
            }
        };
        mainPanel.setLayout(new BorderLayout(15, 15));
        mainPanel.setBorder(new EmptyBorder(15, 15, 15, 15));
        setContentPane(mainPanel);

        // Chat area với border viền màu động
        chatArea = new JTextArea();
        chatArea.setEditable(false);
        chatArea.setLineWrap(true);
        chatArea.setWrapStyleWord(true);
        chatArea.setFont(new Font("Consolas", Font.BOLD, 16));
        chatArea.setOpaque(false);
        chatArea.setForeground(getDynamicColor());

        JScrollPane scrollPane = new JScrollPane(chatArea);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.setBorder(new CompoundBorder(
                new LineBorder(getDynamicBorderColor(), 4, true),
                new EmptyBorder(12, 12, 12, 12)));

        // Panel nhập tin nhắn
        JPanel inputPanel = new JPanel(new BorderLayout(10, 10));
        inputPanel.setOpaque(false);

        inputField = new JTextField();
        inputField.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        inputField.setBorder(new CompoundBorder(
                new LineBorder(new Color(255, 140, 0), 2, true),
                new EmptyBorder(8, 8, 8, 8)));
        inputField.setForeground(new Color(40, 40, 40));

        sendButton = new JButton("Gửi");
        sendButton.setFont(new Font("Segoe UI", Font.BOLD, 18));
        sendButton.setForeground(Color.WHITE);
        sendButton.setBackground(new Color(255, 140, 0));
        sendButton.setFocusPainted(false);
        sendButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        sendButton.setBorder(new LineBorder(new Color(255, 69, 0), 2, true));

        sendButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                sendButton.setBackground(new Color(255, 69, 0));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                sendButton.setBackground(new Color(255, 140, 0));
            }
        });

        inputPanel.add(inputField, BorderLayout.CENTER);
        inputPanel.add(sendButton, BorderLayout.EAST);

        mainPanel.add(scrollPane, BorderLayout.CENTER);
        mainPanel.add(inputPanel, BorderLayout.SOUTH);

        // Hiển thị câu chào đầu tiên
        chatArea.append("Bot: Chào bạn! Tôi có thể giúp gì cho bạn?\n\n");

        // Sự kiện gửi tin nhắn
        sendButton.addActionListener(e -> sendMessage());
        inputField.addActionListener(e -> sendMessage());

        // Timer chạy hiệu ứng màu chữ gradient động trong chatArea
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                hue += 0.005f;
                borderHue += 0.007f;
                sparkleHue += 0.004f;
                if (hue > 1f) hue = 0f;
                if (borderHue > 1f) borderHue = 0f;
                if (sparkleHue > 1f) sparkleHue = 0f;
                SwingUtilities.invokeLater(() -> {
                    chatArea.setForeground(getDynamicColor());
                    scrollPane.setBorder(new CompoundBorder(
                            new LineBorder(getDynamicBorderColor(), 4, true),
                            new EmptyBorder(12, 12, 12, 12)));
                    repaint();
                });
            }
        }, 0, 40);
    }

    // Tạo màu sắc chuyển động dựa trên hue cho chữ
    private Color getDynamicColor() {
        return Color.getHSBColor(hue, 0.8f, 0.85f);
    }

    // Tạo màu sắc chuyển động dựa trên borderHue cho viền
    private Color getDynamicBorderColor() {
        return Color.getHSBColor(borderHue, 0.9f, 0.95f);
    }

    private void sendMessage() {
        String message = inputField.getText().trim();
        if (message.isEmpty()) return;

        chatArea.append("Bạn: " + message + "\n");

        chatArea.append("Bot: " + autoReply(message) + "\n\n");

        inputField.setText("");
        chatArea.setCaretPosition(chatArea.getDocument().getLength());
    }

    private String autoReply(String message) {
        message = message.toLowerCase();

        // Các phản hồi hỗ trợ thông thường
        if (message.contains("xin chào") || message.contains("hello") || message.contains("chào")) {
            return "Chào bạn! Tôi có thể giúp gì cho bạn?";
        } else if (message.contains("giá") || message.contains("bao nhiêu") || message.contains("tính tiền")) {
            return "Bạn vui lòng cho tôi biết sản phẩm bạn quan tâm nhé.";
        } else if (message.contains("đặt hàng") || message.contains("mua") || message.contains("mua hàng")) {
            return "Bạn có thể đặt hàng qua phần Mua sắm trên ứng dụng hoặc liên hệ hotline để được hỗ trợ.";
        } else if (message.contains("thời gian giao hàng") || message.contains("bao lâu")) {
            return "Thời gian giao hàng thường từ 2-5 ngày tùy khu vực.";
        } else if (message.contains("phương thức thanh toán") || message.contains("thanh toán")) {
            return "Chúng tôi hỗ trợ thanh toán qua thẻ tín dụng, chuyển khoản hoặc tiền mặt khi nhận hàng.";
        } else if (message.contains("hủy đơn hàng") || message.contains("đổi trả")) {
            return "Bạn có thể hủy hoặc đổi trả đơn hàng trong vòng 7 ngày kể từ khi nhận hàng.";
        } else if (message.contains("hotline") || message.contains("liên hệ")) {
            return "Bạn có thể gọi số hotline 1900-1234 để được hỗ trợ nhanh nhất.";
        } else if (message.contains("cảm ơn") || message.contains("thanks")) {
            return "Rất vui được hỗ trợ bạn! Nếu còn thắc mắc gì hãy hỏi nhé.";
        } else if (message.contains("tạm biệt") || message.contains("thoát") || message.contains("bye")) {
            return "Cảm ơn bạn đã liên hệ. Chúc bạn một ngày tốt lành!";

        // Các phản hồi cà khịa hài hước
        } else if (message.contains("lười")) {
            return "Lười như bạn thì Google còn chào thua.";
        } else if (message.contains("thi") || message.contains("điểm")) {
            return "Bạn đi thi là niềm vui của giám khảo đó.";
        } else if (message.contains("ngu quá") || message.contains("não")) {
            return "Não bạn chắc đang để ở chế độ bay tiết kiệm.";
        } else if (message.contains("tao đẹp không") || message.contains("đẹp")) {
            return "Bạn đúng là ánh sáng... chói quá không nhìn nổi.";
        } else if (message.contains("tao muốn tao thống minh hơn.") || message.contains("trễ")) {
            return "Ngủ muộn không làm bạn thông minh hơn đâu nha!";
        } else if (message.contains("tình yêu") || message.contains("crush")) {
            return "Tình yêu của bạn giống như bug: biết rõ nhưng sửa hoài không được.";
        } else if (message.contains("thấy bạn tao đâu không") || message.contains("kết bạn")) {
            return "Bạn như WiFi yếu – lúc cần thì không thấy đâu.";
        } else if (message.contains("trí tuệ") || message.contains("iq")) {
            return "Nói chuyện với bạn xong, mình thấy IQ giảm 10 điểm.";
        } else if (message.contains("tấu hài")) {
            return "Bạn mà đi thi 'tấu hài' chắc không ai dám đăng ký nữa.";
        } else if (message.contains("não cá vàng")) {
            return "Bộ nhớ bạn chắc đang hoạt động theo kiểu FIFO – vào trước quên trước!";

        // Phản hồi với tin nhắn mang tính xúc phạm hoặc tự ti
        } else if (message.contains("tôi ngu") || message.contains("m dốt") || message.contains("tao ngu")) {
            return "Không ai ngu cả, có mầy ngu thôi. Cố lên nào!";
        } else if (message.contains("cút đi") || message.contains("biến đi") || message.contains("im đi")) {
            return "không thích làm gì được nhau , đánh nhau tí đi coi ai hơn.";
        } else if (message.contains("mày") && (message.contains("ngu") || message.contains("dốt") || message.contains("đần"))) {
            return "Tớ không buồn đâu, nhưng bạn nên bình tĩnh hơn một chút nhé 🤖✨.";
        }

        // Mặc định
        return "Xin lỗi, tôi chưa hiểu câu hỏi của bạn. Bạn vui lòng hỏi lại hoặc gọi hotline để được hỗ trợ.";
    }



    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ChatUI chat = new ChatUI();
            chat.setVisible(true);
        });
    }
}
