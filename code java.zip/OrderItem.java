package do_an.model;

public class OrderItem {
    private int orderItemPk;
    private String orderId;
    private String productId;
    private String sellerId;
    private float price;

    public OrderItem(int orderItemPk, String orderId, String productId, String sellerId, float price) {
        this.orderItemPk = orderItemPk;
        this.orderId = orderId;
        this.productId = productId;
        this.sellerId = sellerId;
        this.price = price;
    }

    // Getters & setters
    public int getOrderItemPk() { return orderItemPk; }
    public void setOrderItemPk(int orderItemPk) { this.orderItemPk = orderItemPk; }

    public String getOrderId() { return orderId; }
    public void setOrderId(String orderId) { this.orderId = orderId; }

    public String getProductId() { return productId; }
    public void setProductId(String productId) { this.productId = productId; }

    public String getSellerId() { return sellerId; }
    public void setSellerId(String sellerId) { this.sellerId = sellerId; }

    public float getPrice() { return price; }
    public void setPrice(float price) { this.price = price; }
}
