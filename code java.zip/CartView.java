package do_an.ui;

import javax.swing.*;
import javax.swing.plaf.basic.BasicTableUI;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
import java.util.*;
import do_an.model.Product;
import java.util.Timer;
import java.util.TimerTask;

public class CartView extends JFrame {
    private JTable tableCart;
    private JButton btnRemove;
    private JButton btnCheckout;
    private JButton btnFavorite;  // nút Yêu thích
    private JLabel lblTotal;
    private Color gridColor = Color.getHSBColor(0f, 1f, 1f);
    private int colorPhase = 0;
    private Timer timer;

    private CustomerDashboard parentDashboard;
    private Map<String, Product> cart;

    public CartView() {
        this(null, new HashMap<>());
    }

    public CartView(CustomerDashboard parent, Map<String, Product> cart) {
        this.parentDashboard = parent;
        this.cart = cart;

        setTitle("Giỏ hàng");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        initComponents();
        startGridAnimation();
        loadCartData();
        addEventHandlers();
    }

    private void initComponents() {
        Color backgroundColor = new Color(18, 18, 25);
        Color textColor = new Color(200, 255, 255);
        Color accentColor = new Color(0, 150, 255);
        Color headerColor = new Color(0, 200, 255);

        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(backgroundColor);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        String[] columns = {"Sản phẩm", "Số lượng", "Giá", "Thành tiền"};
        DefaultTableModel model = new DefaultTableModel(columns, 0) {
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tableCart = new JTable(model);
        tableCart.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        tableCart.setRowHeight(28);
        tableCart.setBackground(backgroundColor);
        tableCart.setForeground(textColor);
        tableCart.setShowGrid(false);
        tableCart.setGridColor(gridColor);
        tableCart.setSelectionBackground(accentColor);
        tableCart.setSelectionForeground(Color.WHITE);

        tableCart.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 16));
        tableCart.getTableHeader().setForeground(Color.WHITE);
        tableCart.getTableHeader().setBackground(headerColor);

        // Cho phép chọn nhiều dòng
        tableCart.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);

        tableCart.setUI(new BasicTableUI() {
            @Override
            public void paint(Graphics g, JComponent c) {
                super.paint(g, c);
                g.setColor(tableCart.getGridColor());

                int rowCount = tableCart.getRowCount();
                int columnCount = tableCart.getColumnCount();
                int rowHeight = tableCart.getRowHeight();
                int tableWidth = tableCart.getWidth();

                JViewport viewport = (JViewport) SwingUtilities.getAncestorOfClass(JViewport.class, tableCart);
                int viewportHeight = (viewport != null) ? viewport.getHeight() : tableCart.getHeight();

                for (int y = 0; y <= viewportHeight; y += rowHeight) {
                    g.fillRect(0, y, tableWidth, 2);
                }

                int x = 0;
                for (int i = 0; i < columnCount; i++) {
                    x += tableCart.getColumnModel().getColumn(i).getWidth();
                    g.fillRect(x, 0, 2, viewportHeight);
                }
            }
        });

        JScrollPane scrollPane = new JScrollPane(tableCart);
        scrollPane.getViewport().setBackground(backgroundColor);
        scrollPane.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY));
        panel.add(scrollPane, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new BorderLayout(5, 5));
        bottomPanel.setBackground(backgroundColor);

        lblTotal = new JLabel("Tổng tiền: 0 đ");
        lblTotal.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTotal.setForeground(Color.YELLOW);
        bottomPanel.add(lblTotal, BorderLayout.WEST);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(backgroundColor);

        btnRemove = new JButton("Xóa sản phẩm");
        btnCheckout = new JButton("Thanh toán");
        btnFavorite = new JButton("Yêu thích");  // nút mới

        styleButton(btnRemove, new Color(255, 70, 70), Color.WHITE);
        styleButton(btnCheckout, accentColor, Color.WHITE);
        styleButton(btnFavorite, new Color(255, 165, 0), Color.WHITE); // màu cam cho nút yêu thích

        buttonPanel.add(btnRemove);
        buttonPanel.add(btnFavorite); // thêm nút yêu thích vào panel
        buttonPanel.add(btnCheckout);

        bottomPanel.add(buttonPanel, BorderLayout.EAST);
        panel.add(bottomPanel, BorderLayout.SOUTH);

        add(panel);
    }

    private void styleButton(JButton button, Color bg, Color fg) {
        button.setBackground(bg);
        button.setForeground(fg);
        button.setFocusPainted(false);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setBorder(BorderFactory.createEmptyBorder(6, 15, 6, 15));
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }

    private void startGridAnimation() {
        timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            public void run() {
                colorPhase = (colorPhase + 5) % 360;
                gridColor = Color.getHSBColor(colorPhase / 360f, 1f, 1f);
                SwingUtilities.invokeLater(() -> {
                    tableCart.setGridColor(gridColor);
                    tableCart.repaint();
                    tableCart.getTableHeader().repaint();
                });
            }
        }, 0, 100);
    }

    public void setCartItems(List<Object[]> items) {
        DefaultTableModel model = (DefaultTableModel) tableCart.getModel();
        model.setRowCount(0);

        double total = 0;
        for (Object[] item : items) {
            String tenSP = (String) item[0];
            int soLuong = (int) item[1];
            double gia = (double) item[2];
            double thanhTien = soLuong * gia;
            total += thanhTien;

            model.addRow(new Object[]{
                    tenSP,
                    soLuong,
                    String.format("%.0f đ", gia),
                    String.format("%.0f đ", thanhTien)
            });
        }
        lblTotal.setText("Tổng tiền: " + String.format("%.0f đ", total));
    }

    private void loadCartData() {
        List<Object[]> items = new ArrayList<>();
        for (Product p : cart.values()) {
            items.add(new Object[]{p.getProductName(), p.getStockQuantity(), p.getPrice()});
        }
        setCartItems(items);
    }

    private void addEventHandlers() {
        btnRemove.addActionListener(e -> {
            // Lấy tất cả các dòng được chọn
            int[] selectedRows = tableCart.getSelectedRows();
            if (selectedRows.length > 0) {
                DefaultTableModel model = (DefaultTableModel) tableCart.getModel();
                // Xóa sản phẩm trong cart dựa vào tên sản phẩm ở từng dòng được chọn
                // Lưu tên để xóa khỏi cart map
                List<String> productsToRemove = new ArrayList<>();
                for (int row : selectedRows) {
                    String productName = (String) model.getValueAt(row, 0);
                    productsToRemove.add(productName);
                }
                // Xóa khỏi cart
                for (String productName : productsToRemove) {
                    cart.remove(productName);
                }
                // Xóa dòng trong bảng từ dưới lên trên để tránh lỗi index
                Arrays.sort(selectedRows);
                for (int i = selectedRows.length - 1; i >= 0; i--) {
                    model.removeRow(selectedRows[i]);
                }
                updateTotal();
            } else {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn sản phẩm cần xóa!", "Thông báo", JOptionPane.WARNING_MESSAGE);
            }
        });

        btnCheckout.addActionListener(e -> {
            if (tableCart.getRowCount() == 0) {
                JOptionPane.showMessageDialog(this, "Giỏ hàng đang trống!", "Thông báo", JOptionPane.WARNING_MESSAGE);
                return;
            }
            int confirm = JOptionPane.showConfirmDialog(this, "Xác nhận thanh toán?", "Thanh toán", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                List<Object[]> orderItems = new ArrayList<>();
                DefaultTableModel model = (DefaultTableModel) tableCart.getModel();
                for (int i = 0; i < model.getRowCount(); i++) {
                    String tenSP = (String) model.getValueAt(i, 0);
                    int soLuong = (int) model.getValueAt(i, 1);
                    String giaStr = ((String) model.getValueAt(i, 2)).replace(" đ", "").replace(".", "");
                    double gia = 0;
                    try {
                        gia = Double.parseDouble(giaStr);
                    } catch (NumberFormatException ex) {
                        gia = 0;
                    }
                    orderItems.add(new Object[]{tenSP, soLuong, gia});
                }

                CheckoutView checkoutView = new CheckoutView();
                checkoutView.setOrderDetails(orderItems);
                checkoutView.setVisible(true);
            }
        });

//        btnFavorite.addActionListener(e -> {
//            int[] selectedRows = tableCart.getSelectedRows();
//            if (selectedRows.length == 0) {
//                JOptionPane.showMessageDialog(this, "Vui lòng chọn sản phẩm để thêm vào yêu thích!", "Thông báo", JOptionPane.WARNING_MESSAGE);
//                return;
//            }
//            DefaultTableModel model = (DefaultTableModel) tableCart.getModel();
//            List<String> favoriteProducts = new ArrayList<>();
//            for (int row : selectedRows) {
//                String productName = (String) model.getValueAt(row, 0);
//                favoriteProducts.add(productName);
//            }
//            // Xử lý thêm yêu thích (ở đây tạm hiện thông báo)
//            JOptionPane.showMessageDialog(this, "Đã thêm " + favoriteProducts.size() + " sản phẩm vào danh sách yêu thích!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
//        });
        btnFavorite.addActionListener(e -> {
            int[] selectedRows = tableCart.getSelectedRows();
            if (selectedRows.length == 0) {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn sản phẩm để thêm vào yêu thích!", "Thông báo", JOptionPane.WARNING_MESSAGE);
                return;
            }

            DefaultTableModel model = (DefaultTableModel) tableCart.getModel();
            int countNewFavorites = 0;
            for (int row : selectedRows) {
                String productName = (String) model.getValueAt(row, 0);
                if (!FavoriteManager.isFavorite(productName)) {
                    FavoriteManager.addFavorite(productName);
                    countNewFavorites++;
                }
            }

            if (countNewFavorites > 0) {
                JOptionPane.showMessageDialog(this, "Đã thêm " + countNewFavorites + " sản phẩm mới vào danh sách yêu thích!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Tất cả sản phẩm đã có trong danh sách yêu thích!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
            }
        });

    }

    private void updateTotal() {
        DefaultTableModel model = (DefaultTableModel) tableCart.getModel();
        double total = 0;
        for (int i = 0; i < model.getRowCount(); i++) {
            String thanhTienStr = model.getValueAt(i, 3).toString().replace(" đ", "").replace(".", "");
            double thanhTien = 0;
            try {
                thanhTien = Double.parseDouble(thanhTienStr);
            } catch (NumberFormatException ex) {
                thanhTien = 0;
            }
            total += thanhTien;
        }
        lblTotal.setText("Tổng tiền: " + String.format("%.0f đ", total));
    }

    public JButton getBtnRemove() {
        return btnRemove;
    }

    public JButton getBtnCheckout() {
        return btnCheckout;
    }

    public JButton getBtnFavorite() {
        return btnFavorite;
    }

    public JTable getTableCart() {
        return tableCart;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            CartView cartView = new CartView();
            cartView.setVisible(true);
        });
    }
}
