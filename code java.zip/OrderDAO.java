package do_an.dao;

import do_an.DBConnection;
import do_an.model.CartItem;
import do_an.model.Product;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;


import do_an.DBConnection;import do_an.model.CartItem;
import do_an.model.Product;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;



import do_an.model.Order;
import do_an.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import do_an.DBConnection;
import do_an.model.CartItem;
import do_an.model.Product;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import do_an.DBConnection;
import do_an.model.CartItem;
import do_an.model.Product;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import do_an.DBConnection;
import do_an.model.CartItem;
import do_an.model.Product;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class OrderDAO {
    private Connection conn;

    public OrderDAO() {
        conn = DBConnection.getConnection();
    }

    public List<Order> getAllOrders() {
        List<Order> list = new ArrayList<>();
        String sql = "SELECT * FROM orders";
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Order order = new Order(
                    rs.getString("order_id"),
                    rs.getDate("order_date"),
                    rs.getString("customer_id")
                );
                list.add(order);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
}
